package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.TransactionCategory
import com.example.ui.components.BudgetProgressCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.viewmodel.SpendlyUiState

private data class BudgetDialogRequest(
    val isOverall: Boolean,
    val initialCategory: TransactionCategory = TransactionCategory.FOOD,
    val existingAmount: Double? = null
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BudgetsScreen(
    uiState: SpendlyUiState,
    onShiftMonth: (Int) -> Unit,
    onSaveBudget: (monthKey: String, categoryName: String, limitAmount: Double) -> Unit,
    onRemoveBudget: (monthKey: String, categoryName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val settings = uiState.settings
    val symbol = settings.currencySymbol
    val indian = settings.useIndianNumbering

    var dialogRequest by remember { mutableStateOf<BudgetDialogRequest?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header & Month Selector
            item(key = "budgets_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Budgets",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onShiftMonth(-1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("budget_prev_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronLeft,
                                contentDescription = "Previous month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = DateUtils.formatShortMonth(uiState.selectedMonthKey) +
                                " " + uiState.selectedMonthKey.take(4),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        IconButton(
                            onClick = { onShiftMonth(1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("budget_next_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = "Next month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Active Warning Alerts Summary
            if (uiState.activeBudgetWarnings.isNotEmpty()) {
                item(key = "warnings_card") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(spendlyColors.warningContainer)
                            .border(1.dp, spendlyColors.warning.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.WarningAmber,
                                contentDescription = "Budget alerts",
                                tint = spendlyColors.warning,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Budget Alerts (${uiState.activeBudgetWarnings.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = spendlyColors.warning
                            )
                        }
                        uiState.activeBudgetWarnings.forEach { alert ->
                            val statusText = if (alert.isExceeded) {
                                "${alert.displayTitle}: Exceeded (${alert.percentUsed}%)"
                            } else {
                                "${alert.displayTitle}: ${alert.percentUsed}% used — " +
                                    "${CurrencyFormatter.format(alert.remainingAmount, symbol, indian)} left"
                            }
                            Text(
                                text = "• $statusText",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Monthly Overall Budget Section
            item(key = "overall_budget") {
                SectionHeader(
                    title = "Overall Monthly Limit",
                    actionLabel = if (uiState.overallMonthlyBudget == null) "Set Limit" else "Edit",
                    onActionClick = {
                        dialogRequest = BudgetDialogRequest(
                            isOverall = true,
                            existingAmount = uiState.overallMonthlyBudget?.limitAmount
                        )
                    }
                )
                Spacer(modifier = Modifier.height(10.dp))

                val overall = uiState.overallMonthlyBudget
                if (overall != null) {
                    BudgetProgressCard(
                        item = overall,
                        currencySymbol = symbol,
                        indianNumbering = indian,
                        onClick = {
                            dialogRequest = BudgetDialogRequest(
                                isOverall = true,
                                existingAmount = overall.limitAmount
                            )
                        }
                    )
                } else {
                    EmptyStateCard(
                        icon = Icons.Rounded.AccountBalanceWallet,
                        title = "No monthly budget set",
                        subtitle = "Set a monthly cap to monitor your spending pace and receive ${settings.warningThresholdPercent}% warning notifications.",
                        actionLabel = "Set Monthly Budget",
                        onActionClick = {
                            dialogRequest = BudgetDialogRequest(isOverall = true)
                        }
                    )
                }
            }

            // Category Budgets Section
            item(key = "category_budgets_header") {
                SectionHeader(
                    title = "Category Budgets",
                    actionLabel = "+ Add Category",
                    onActionClick = {
                        val existingCats = uiState.categoryBudgets.mapNotNull { it.category }.toSet()
                        val nextAvailable = TransactionCategory.expenseCategories()
                            .firstOrNull { it !in existingCats } ?: TransactionCategory.FOOD
                        dialogRequest = BudgetDialogRequest(
                            isOverall = false,
                            initialCategory = nextAvailable
                        )
                    }
                )
            }

            if (uiState.categoryBudgets.isEmpty()) {
                item(key = "empty_cat_budgets") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(20.dp))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Track specific categories like Food, Shopping, or Travel",
                            style = MaterialTheme.typography.bodyMedium,
                            color = spendlyColors.mutedText
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                dialogRequest = BudgetDialogRequest(
                                    isOverall = false,
                                    initialCategory = TransactionCategory.FOOD
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("add_category_budget_button")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Category Budget")
                        }
                    }
                }
            } else {
                items(
                    items = uiState.categoryBudgets,
                    key = { "cat_budget_${it.categoryName}" }
                ) { budget ->
                    BudgetProgressCard(
                        item = budget,
                        currencySymbol = symbol,
                        indianNumbering = indian,
                        onClick = {
                            dialogRequest = BudgetDialogRequest(
                                isOverall = false,
                                initialCategory = budget.category ?: TransactionCategory.FOOD,
                                existingAmount = budget.limitAmount
                            )
                        }
                    )
                }
            }

            item(key = "bottom_spacer") { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    // Set / Edit Budget Dialog
    val activeReq = dialogRequest
    if (activeReq != null) {
        var selectedCategory by remember(activeReq) { mutableStateOf(activeReq.initialCategory) }
        var limitText by remember(activeReq) {
            mutableStateOf(
                activeReq.existingAmount?.let {
                    if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                } ?: ""
            )
        }
        var errorMsg by remember(activeReq) { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { dialogRequest = null },
            containerColor = spendlyColors.cardSurface,
            title = {
                Text(
                    text = if (activeReq.isOverall) "Monthly Overall Budget" else "Category Budget",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Applies to ${DateUtils.formatMonthLabel(uiState.selectedMonthKey)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = spendlyColors.mutedText
                    )

                    if (!activeReq.isOverall) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            TransactionCategory.expenseCategories().forEach { cat ->
                                val isSel = selectedCategory == cat
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (isSel) cat.accentColor.copy(alpha = 0.22f)
                                            else spendlyColors.elevatedCard
                                        )
                                        .border(
                                            1.dp,
                                            if (isSel) cat.accentColor else spendlyColors.subtleBorder,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selectedCategory = cat }
                                        .padding(horizontal = 10.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = cat.icon,
                                        contentDescription = cat.displayName,
                                        tint = cat.accentColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = cat.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = limitText,
                        onValueChange = { raw ->
                            val clean = raw.filter { it.isDigit() || it == '.' }
                            if (clean.count { it == '.' } <= 1 && clean.length <= 12) {
                                limitText = clean
                                errorMsg = null
                            }
                        },
                        label = { Text("Budget Limit ($symbol)") },
                        prefix = {
                            Text(
                                "$symbol ",
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily)
                            )
                        },
                        singleLine = true,
                        isError = errorMsg != null,
                        supportingText = errorMsg?.let { msg -> { Text(msg) } },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("budget_amount_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val parsed = limitText.toDoubleOrNull()
                        if (parsed == null || !parsed.isFinite() || parsed <= 0.0) {
                            errorMsg = "Enter a valid budget above 0"
                        } else {
                            val key = if (activeReq.isOverall) {
                                TransactionCategory.OVERALL_BUDGET_KEY
                            } else {
                                selectedCategory.name
                            }
                            onSaveBudget(uiState.selectedMonthKey, key, parsed)
                            dialogRequest = null
                        }
                    },
                    modifier = Modifier.testTag("save_budget_confirm_button")
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row {
                    if (activeReq.existingAmount != null) {
                        TextButton(
                            onClick = {
                                val key = if (activeReq.isOverall) {
                                    TransactionCategory.OVERALL_BUDGET_KEY
                                } else {
                                    selectedCategory.name
                                }
                                onRemoveBudget(uiState.selectedMonthKey, key)
                                dialogRequest = null
                            }
                        ) {
                            Text("Remove", color = spendlyColors.expense)
                        }
                    }
                    TextButton(onClick = { dialogRequest = null }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}
