package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.viewmodel.CategorySpendSlice
import com.example.viewmodel.ChartBarPoint
import com.example.viewmodel.MonthlyComparisonPoint
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Interactive single-series bar chart used for Daily, Weekly, and Monthly expense tracking.
 * Morphs smoothly with spring physics whenever new transactions update the series.
 */
@Composable
fun InteractiveExpenseBarChart(
    points: List<ChartBarPoint>,
    currencySymbol: String,
    indianNumbering: Boolean,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val entrance = remember { Animatable(0f) }
    var selectedIndex by remember(points.size) {
        mutableIntStateOf(
            points.indexOfLast { it.value > 0.0 }.coerceAtLeast(points.lastIndex.coerceAtLeast(0))
        )
    }

    // Keep selection valid and auto-focus latest non-zero point when data updates
    val totalValue = remember(points) { points.sumOf { it.value } }
    LaunchedEffect(points.size, totalValue) {
        val latestNonZero = points.indexOfLast { it.value > 0.0 }
        if (latestNonZero >= 0) {
            selectedIndex = latestNonZero
        } else if (points.isNotEmpty()) {
            selectedIndex = selectedIndex.coerceIn(0, points.lastIndex)
        }
        if (entrance.value < 1f) {
            entrance.animateTo(1f, animationSpec = tween(550, easing = FastOutSlowInEasing))
        }
    }

    val safeSelectedIndex = selectedIndex.coerceIn(0, points.lastIndex.coerceAtLeast(0))
    val maxVal = remember(points) {
        (points.maxOfOrNull { it.value } ?: 0.0).coerceAtLeast(1.0)
    }

    // Smooth per-bar spring animations so adding/editing transactions updates bars live
    val animatedRatios = points.mapIndexed { idx, pt ->
        val target = ((pt.value / maxVal).toFloat().coerceIn(0f, 1f)) * entrance.value
        animateFloatAsState(
            targetValue = target,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            ),
            label = "expense_bar_$idx"
        ).value
    }

    val selectedPoint = points.getOrNull(safeSelectedIndex)
    val chartDescription = if (selectedPoint != null) {
        "Expense bar chart. Selected ${selectedPoint.fullLabel}: " +
            CurrencyFormatter.format(selectedPoint.value, currencySymbol, indianNumbering)
    } else {
        "Expense bar chart"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = chartDescription }
    ) {
        if (selectedPoint != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(spendlyColors.elevatedCard)
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedPoint.fullLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = spendlyColors.mutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = CurrencyFormatter.format(
                        selectedPoint.value,
                        currencySymbol,
                        indianNumbering
                    ),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = barColor,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Subtle peak reference label for quick scale comprehension
        if (totalValue > 0.0) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Peak ${CurrencyFormatter.formatCompact(maxVal, currencySymbol, indianNumbering)}",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily, fontSize = 10.sp),
                    color = spendlyColors.mutedText
                )
                Text(
                    text = "Total ${CurrencyFormatter.formatCompact(totalValue, currencySymbol, indianNumbering)}",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily, fontSize = 10.sp),
                    color = spendlyColors.mutedText
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        val gridColor = spendlyColors.subtleBorder.copy(alpha = 0.65f)
        val dimBarColor = barColor.copy(alpha = 0.34f)

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(172.dp)
                .pointerInput(points) {
                    detectTapGestures { tapOffset ->
                        if (points.isNotEmpty() && size.width > 0) {
                            val slotWidth = size.width.toFloat() / points.size
                            selectedIndex = (tapOffset.x / slotWidth).toInt().coerceIn(0, points.lastIndex)
                        }
                    }
                }
        ) {
            val chartHeight = size.height - 10.dp.toPx()
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
            for (i in 0..3) {
                val y = chartHeight * (i / 3f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = if (i < 3) dashEffect else null
                )
            }

            if (points.isEmpty()) return@Canvas
            val slotWidth = size.width / points.size
            val barWidth = (slotWidth * 0.56f).coerceIn(6.dp.toPx(), 28.dp.toPx())
            val corner = CornerRadius(6.dp.toPx(), 6.dp.toPx())

            points.forEachIndexed { idx, point ->
                val ratio = animatedRatios.getOrElse(idx) { 0f }
                val barHeight = max(
                    ratio * (chartHeight - 10.dp.toPx()),
                    if (point.value > 0) 5.dp.toPx() else 2.dp.toPx()
                )
                val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                val top = chartHeight - barHeight
                val isSelected = idx == safeSelectedIndex

                if (isSelected && point.value > 0) {
                    // Subtle vertical highlight halo behind selected bar
                    drawRoundRect(
                        color = barColor.copy(alpha = 0.14f),
                        topLeft = Offset(left - 3.dp.toPx(), 0f),
                        size = Size(barWidth + 6.dp.toPx(), chartHeight),
                        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                    )
                }

                drawRoundRect(
                    brush = if (isSelected) {
                        Brush.verticalGradient(listOf(barColor, barColor.copy(alpha = 0.72f)))
                    } else {
                        Brush.verticalGradient(listOf(dimBarColor, dimBarColor.copy(alpha = 0.52f)))
                    },
                    topLeft = Offset(left, top),
                    size = Size(barWidth, barHeight),
                    cornerRadius = corner
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        val step = if (points.size > 8) 2 else 1
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            points.forEachIndexed { index, point ->
                val showLabel = index % step == 0 || index == points.lastIndex
                Text(
                    text = if (showLabel) point.label else "",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = if (index == safeSelectedIndex) barColor else spendlyColors.mutedText,
                    fontWeight = if (index == safeSelectedIndex) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * Grouped Income vs Expense bar chart with spring-animated live updates, tap inspection, and legend.
 */
@Composable
fun IncomeVsExpenseChart(
    series: List<MonthlyComparisonPoint>,
    currencySymbol: String,
    indianNumbering: Boolean,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val entrance = remember { Animatable(0f) }
    var selectedIndex by remember(series.size) {
        mutableIntStateOf((series.lastIndex).coerceAtLeast(0))
    }

    val seriesSignature = remember(series) {
        series.sumOf { it.income + it.expense }
    }

    LaunchedEffect(series.size, seriesSignature) {
        if (series.isNotEmpty()) {
            selectedIndex = selectedIndex.coerceIn(0, series.lastIndex)
        }
        if (entrance.value < 1f) {
            entrance.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        }
    }

    val safeSelected = selectedIndex.coerceIn(0, series.lastIndex.coerceAtLeast(0))
    val maxVal = remember(series) {
        series.maxOfOrNull { max(it.income, it.expense) }?.coerceAtLeast(1.0) ?: 1.0
    }

    val animatedIncomeRatios = series.mapIndexed { idx, pt ->
        animateFloatAsState(
            targetValue = ((pt.income / maxVal).toFloat().coerceIn(0f, 1f)) * entrance.value,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            ),
            label = "inc_bar_$idx"
        ).value
    }
    val animatedExpenseRatios = series.mapIndexed { idx, pt ->
        animateFloatAsState(
            targetValue = ((pt.expense / maxVal).toFloat().coerceIn(0f, 1f)) * entrance.value,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            ),
            label = "exp_bar_$idx"
        ).value
    }

    val active = series.getOrNull(safeSelected)
    val chartDesc = if (active != null) {
        "Income versus expenses chart. ${active.shortLabel}: income " +
            "${CurrencyFormatter.formatCompact(active.income, currencySymbol, indianNumbering)}, " +
            "expenses ${CurrencyFormatter.formatCompact(active.expense, currencySymbol, indianNumbering)}"
    } else {
        "Income versus expenses chart"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = chartDesc }
    ) {
        if (active != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(spendlyColors.elevatedCard)
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = active.shortLabel,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(spendlyColors.income)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = CurrencyFormatter.formatCompact(active.income, currencySymbol, indianNumbering),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = MonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = spendlyColors.income,
                            maxLines = 1
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(spendlyColors.expense)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = CurrencyFormatter.formatCompact(active.expense, currencySymbol, indianNumbering),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = MonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = spendlyColors.expense,
                            maxLines = 1
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        val gridColor = spendlyColors.subtleBorder.copy(alpha = 0.6f)
        val incomeColor = spendlyColors.income
        val expenseColor = spendlyColors.expense

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(164.dp)
                .pointerInput(series) {
                    detectTapGestures { offset ->
                        if (series.isNotEmpty() && size.width > 0) {
                            val groupWidth = size.width.toFloat() / series.size
                            selectedIndex = (offset.x / groupWidth).toInt().coerceIn(0, series.lastIndex)
                        }
                    }
                }
        ) {
            val chartHeight = size.height - 8.dp.toPx()
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
            for (i in 0..3) {
                val y = chartHeight * (i / 3f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = if (i < 3) dashEffect else null
                )
            }

            if (series.isEmpty()) return@Canvas
            val groupWidth = size.width / series.size
            val barWidth = (groupWidth * 0.28f).coerceIn(6.dp.toPx(), 16.dp.toPx())
            val barGap = 4.dp.toPx()
            val corner = CornerRadius(5.dp.toPx(), 5.dp.toPx())

            series.forEachIndexed { idx, point ->
                val isSelected = idx == safeSelected
                val alpha = if (isSelected) 1f else 0.42f
                val groupCenter = idx * groupWidth + groupWidth / 2f

                val incHeight = max(
                    animatedIncomeRatios.getOrElse(idx) { 0f } * (chartHeight - 10.dp.toPx()),
                    if (point.income > 0) 5.dp.toPx() else 2.dp.toPx()
                )
                val expHeight = max(
                    animatedExpenseRatios.getOrElse(idx) { 0f } * (chartHeight - 10.dp.toPx()),
                    if (point.expense > 0) 5.dp.toPx() else 2.dp.toPx()
                )

                if (isSelected && (point.income > 0 || point.expense > 0)) {
                    drawRoundRect(
                        color = gridColor.copy(alpha = 0.25f),
                        topLeft = Offset(groupCenter - barWidth - barGap, 0f),
                        size = Size((barWidth * 2) + (barGap * 2), chartHeight),
                        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                    )
                }

                drawRoundRect(
                    brush = Brush.verticalGradient(
                        listOf(incomeColor.copy(alpha = alpha), incomeColor.copy(alpha = alpha * 0.72f))
                    ),
                    topLeft = Offset(groupCenter - barWidth - barGap / 2f, chartHeight - incHeight),
                    size = Size(barWidth, incHeight),
                    cornerRadius = corner
                )
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        listOf(expenseColor.copy(alpha = alpha), expenseColor.copy(alpha = alpha * 0.72f))
                    ),
                    topLeft = Offset(groupCenter + barGap / 2f, chartHeight - expHeight),
                    size = Size(barWidth, expHeight),
                    cornerRadius = corner
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            series.forEachIndexed { idx, point ->
                Text(
                    text = point.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (idx == safeSelected) MaterialTheme.colorScheme.onSurface else spendlyColors.mutedText,
                    fontWeight = if (idx == safeSelected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * Interactive Category Donut Chart with smooth animated sweep, auto-updated slices, and tap inspection.
 */
@Composable
fun CategoryDonutChart(
    slices: List<CategorySpendSlice>,
    currencySymbol: String,
    indianNumbering: Boolean,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val totalSpend = remember(slices) { slices.sumOf { it.amount } }
    val animProgress = remember { Animatable(0f) }
    var selectedIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(slices.size, totalSpend) {
        if (slices.isNotEmpty()) {
            selectedIndex = selectedIndex.coerceIn(0, slices.lastIndex)
        } else {
            selectedIndex = 0
        }
        animProgress.snapTo(if (animProgress.value == 0f) 0f else 0.78f)
        animProgress.animateTo(1f, animationSpec = tween(550, easing = FastOutSlowInEasing))
    }

    val safeSelected = selectedIndex.coerceIn(0, slices.lastIndex.coerceAtLeast(0))
    val selectedSlice = slices.getOrNull(safeSelected)

    val animatedSweeps = slices.mapIndexed { idx, slice ->
        val target = if (totalSpend > 0.0) (slice.amount / totalSpend * 360.0).toFloat() else 0f
        animateFloatAsState(
            targetValue = target * animProgress.value,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "donut_slice_$idx"
        ).value
    }

    val chartDesc = if (selectedSlice != null) {
        "Category spending donut chart. Selected ${selectedSlice.category.displayName}: " +
            "${CurrencyFormatter.format(selectedSlice.amount, currencySymbol, indianNumbering)}, " +
            "${String.format("%.1f", selectedSlice.percentage)} percent."
    } else {
        "Category spending donut chart"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = chartDesc },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(206.dp),
            contentAlignment = Alignment.Center
        ) {
            val trackColor = spendlyColors.elevatedCard

            Canvas(
                modifier = Modifier
                    .size(206.dp)
                    .pointerInput(slices) {
                        detectTapGestures { tap ->
                            if (slices.isEmpty() || totalSpend <= 0.0) return@detectTapGestures
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            val dx = tap.x - cx
                            val dy = tap.y - cy
                            val dist = hypot(dx, dy)
                            if (dist < size.width * 0.2f) return@detectTapGestures
                            var angle = (atan2(dy.toDouble(), dx.toDouble()) * 180.0 / PI).toFloat() + 90f
                            if (angle < 0f) angle += 360f
                            var acc = 0f
                            slices.forEachIndexed { idx, slice ->
                                val sweep = (slice.amount / totalSpend * 360.0).toFloat()
                                if (angle in acc..(acc + sweep)) {
                                    selectedIndex = idx
                                }
                                acc += sweep
                            }
                        }
                    }
            ) {
                val strokeWidth = 26.dp.toPx()
                val inset = strokeWidth / 2f + 10.dp.toPx()
                val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
                val topLeft = Offset(inset, inset)

                drawArc(
                    color = trackColor,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth)
                )

                var startAngle = -90f
                val gapDegrees = if (slices.size > 1) 2.5f else 0f
                slices.forEachIndexed { idx, slice ->
                    val rawSweep = animatedSweeps.getOrElse(idx) { 0f }
                    val drawSweep = (rawSweep - gapDegrees).coerceAtLeast(0.5f)
                    val isSelected = idx == safeSelected
                    val activeStroke = if (isSelected) strokeWidth + 6.dp.toPx() else strokeWidth
                    drawArc(
                        color = slice.category.accentColor.copy(alpha = if (isSelected) 1f else 0.72f),
                        startAngle = startAngle,
                        sweepAngle = drawSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = activeStroke, cap = StrokeCap.Butt)
                    )
                    startAngle += rawSweep
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = selectedSlice?.category?.displayName ?: "Total",
                    style = MaterialTheme.typography.labelMedium,
                    color = spendlyColors.mutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = CurrencyFormatter.formatCompact(
                        selectedSlice?.amount ?: totalSpend,
                        currencySymbol,
                        indianNumbering
                    ),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                if (selectedSlice != null) {
                    Text(
                        text = "${String.format("%.1f", selectedSlice.percentage)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = selectedSlice.category.accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            slices.forEachIndexed { index, slice ->
                val isSelected = index == safeSelected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isSelected) spendlyColors.elevatedCard else Color.Transparent
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSelected) slice.category.accentColor.copy(alpha = 0.5f)
                            else spendlyColors.subtleBorder.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .pointerInput(index) {
                            detectTapGestures { selectedIndex = index }
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryIconBadge(category = slice.category, sizeDp = 34)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = slice.category.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${String.format("%.1f", slice.percentage)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = spendlyColors.mutedText
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = CurrencyFormatter.format(slice.amount, currencySymbol, indianNumbering),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = MonoFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * Interactive Savings Trends smooth line & gradient area chart with live morphing point transitions.
 */
@Composable
fun SavingsTrendChart(
    points: List<ChartBarPoint>,
    currencySymbol: String,
    indianNumbering: Boolean,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val entrance = remember { Animatable(0f) }
    var selectedIndex by remember(points.size) { mutableIntStateOf((points.lastIndex).coerceAtLeast(0)) }

    val totalSig = remember(points) { points.sumOf { it.value } }
    LaunchedEffect(points.size, totalSig) {
        if (points.isNotEmpty()) {
            selectedIndex = selectedIndex.coerceIn(0, points.lastIndex)
        }
        if (entrance.value < 1f) {
            entrance.animateTo(1f, animationSpec = tween(650, easing = FastOutSlowInEasing))
        }
    }

    val safeSelected = selectedIndex.coerceIn(0, points.lastIndex.coerceAtLeast(0))
    val minVal = remember(points) { min(0.0, points.minOfOrNull { it.value } ?: 0.0) }
    val maxVal = remember(points) { max(1.0, points.maxOfOrNull { it.value } ?: 1.0) }
    val valueRange = (maxVal - minVal).coerceAtLeast(1.0)

    val animatedNormalized = points.mapIndexed { idx, pt ->
        val targetNorm = (((pt.value * entrance.value) - minVal) / valueRange).toFloat().coerceIn(0f, 1f)
        animateFloatAsState(
            targetValue = targetNorm,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            ),
            label = "savings_pt_$idx"
        ).value
    }

    val selected = points.getOrNull(safeSelected)
    val chartDesc = if (selected != null) {
        "Savings trends chart. ${selected.fullLabel}: " +
            CurrencyFormatter.format(selected.value, currencySymbol, indianNumbering, showPlusSign = true)
    } else {
        "Savings trends chart"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = chartDesc }
    ) {
        if (selected != null) {
            val valColor = if (selected.value >= 0.0) spendlyColors.income else spendlyColors.expense
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(spendlyColors.elevatedCard)
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selected.fullLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = spendlyColors.mutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = CurrencyFormatter.format(
                        selected.value,
                        currencySymbol,
                        indianNumbering,
                        showPlusSign = true
                    ),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = valColor,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        val lineColor = spendlyColors.income
        val negColor = spendlyColors.expense
        val gridColor = spendlyColors.subtleBorder.copy(alpha = 0.6f)
        val dotCenterColor = spendlyColors.cardSurface

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(172.dp)
                .pointerInput(points) {
                    detectTapGestures { tap ->
                        if (points.size > 1 && size.width > 0) {
                            val stepX = size.width.toFloat() / (points.size - 1)
                            selectedIndex = ((tap.x / stepX) + 0.5f).toInt().coerceIn(0, points.lastIndex)
                        }
                    }
                }
        ) {
            val padTop = 14.dp.toPx()
            val padBottom = 14.dp.toPx()
            val padX = 12.dp.toPx()
            val usableH = (size.height - padTop - padBottom).coerceAtLeast(1f)
            val usableW = (size.width - padX * 2).coerceAtLeast(1f)

            val zeroNorm = ((0.0 - minVal) / valueRange).toFloat().coerceIn(0f, 1f)
            val zeroY = padTop + usableH * (1f - zeroNorm)

            drawLine(
                color = gridColor,
                start = Offset(0f, zeroY),
                end = Offset(size.width, zeroY),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
            )

            if (points.size < 2) return@Canvas
            val stepX = usableW / (points.size - 1)
            val coords = points.indices.map { idx ->
                val norm = animatedNormalized.getOrElse(idx) { zeroNorm }
                Offset(padX + idx * stepX, padTop + usableH * (1f - norm))
            }

            val linePath = Path().apply {
                moveTo(coords.first().x, coords.first().y)
                for (i in 1 until coords.size) {
                    val prev = coords[i - 1]
                    val curr = coords[i]
                    val midX = (prev.x + curr.x) / 2f
                    cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                }
            }

            val areaPath = Path().apply {
                addPath(linePath)
                lineTo(coords.last().x, zeroY)
                lineTo(coords.first().x, zeroY)
                close()
            }

            drawPath(
                path = areaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        lineColor.copy(alpha = 0.28f),
                        lineColor.copy(alpha = 0.02f)
                    ),
                    startY = padTop,
                    endY = size.height
                )
            )

            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            coords.forEachIndexed { idx, offset ->
                val isSelected = idx == safeSelected
                val pointColor = if (points[idx].value >= 0) lineColor else negColor
                if (isSelected) {
                    drawCircle(
                        color = pointColor.copy(alpha = 0.22f),
                        radius = 12.dp.toPx(),
                        center = offset
                    )
                }
                val outerRadius = if (isSelected) 7.dp.toPx() else 4.5.dp.toPx()
                drawCircle(color = pointColor, radius = outerRadius, center = offset)
                drawCircle(color = dotCenterColor, radius = outerRadius * 0.45f, center = offset)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            points.forEachIndexed { idx, pt ->
                Text(
                    text = pt.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (idx == safeSelected) lineColor else spendlyColors.mutedText,
                    fontWeight = if (idx == safeSelected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}
