package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ads.AdConfig
import com.example.ads.AdaptiveBannerAd
import com.example.ads.NativeTransactionAdCard
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.viewmodel.DateRangeFilter
import com.example.viewmodel.SpendlyUiState

private sealed interface HistoryListEntry {
    data class DateHeader(val label: String) : HistoryListEntry
    data class TxItem(val transaction: TransactionEntity) : HistoryListEntry
    data class NativeAdSlot(val slotIndex: Int) : HistoryListEntry
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TransactionsScreen(
    uiState: SpendlyUiState,
    onSearchChange: (String) -> Unit,
    onTypeFilterChange: (TransactionType?) -> Unit,
    onCategoryFilterChange: (TransactionCategory?) -> Unit,
    onDateRangeChange: (DateRangeFilter) -> Unit,
    onCustomDateRangeSelected: (Long, Long) -> Unit,
    onClearFilters: () -> Unit,
    onAddTransaction: () -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val settings = uiState.settings
    val symbol = settings.currencySymbol
    val indian = settings.useIndianNumbering
    val filters = uiState.filters

    var showCategoryFilterSheet by remember { mutableStateOf(false) }
    var showCustomDateDialog by remember { mutableStateOf(false) }
    var pendingDeleteTx by remember { mutableStateOf<TransactionEntity?>(null) }

    val filtered = uiState.filteredTransactions
    val filteredIncome = remember(filtered) {
        filtered.filter { it.transactionType == TransactionType.INCOME }.sumOf { it.amount }
    }
    val filteredExpense = remember(filtered) {
        filtered.filter { it.transactionType == TransactionType.EXPENSE }.sumOf { it.amount }
    }

    // Build flattened list with Date headers + Native Ad every 9 transactions (between 8-10 items)
    val listEntries = remember(filtered) {
        val entries = mutableListOf<HistoryListEntry>()
        var lastHeader: String? = null
        var txCount = 0
        var adSlot = 0
        filtered.forEach { tx ->
            val header = DateUtils.formatSectionDate(tx.timestamp)
            if (header != lastHeader) {
                entries.add(HistoryListEntry.DateHeader(header))
                lastHeader = header
            }
            entries.add(HistoryListEntry.TxItem(tx))
            txCount++
            if (txCount % AdConfig.NATIVE_AD_INTERVAL == 0 && txCount < filtered.size) {
                adSlot++
                entries.add(HistoryListEntry.NativeAdSlot(adSlot))
            }
        }
        entries
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                // Header & Search
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Transactions",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        if (filters.hasActiveFilters) {
                            Text(
                                text = "Reset Filters",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onClearFilters)
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("reset_filters_button")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = filters.searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text("Search notes, categories, or amount…") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = spendlyColors.mutedText
                            )
                        },
                        trailingIcon = {
                            if (filters.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Clear,
                                        contentDescription = "Clear search"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = spendlyColors.cardSurface,
                            unfocusedContainerColor = spendlyColors.cardSurface,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = spendlyColors.subtleBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transaction_search_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Filter Chips Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Type Filter Chips
                        FilterPill(
                            label = "All",
                            selected = filters.typeFilter == null,
                            onClick = { onTypeFilterChange(null) },
                            tag = "filter_type_all"
                        )
                        FilterPill(
                            label = "Expenses",
                            selected = filters.typeFilter == TransactionType.EXPENSE,
                            onClick = {
                                onTypeFilterChange(
                                    if (filters.typeFilter == TransactionType.EXPENSE) null else TransactionType.EXPENSE
                                )
                            },
                            tag = "filter_type_expense"
                        )
                        FilterPill(
                            label = "Income",
                            selected = filters.typeFilter == TransactionType.INCOME,
                            onClick = {
                                onTypeFilterChange(
                                    if (filters.typeFilter == TransactionType.INCOME) null else TransactionType.INCOME
                                )
                            },
                            tag = "filter_type_income"
                        )

                        // Category Filter Selector Chip
                        FilterPill(
                            label = filters.categoryFilter?.displayName ?: "Category",
                            selected = filters.categoryFilter != null,
                            leadingIcon = Icons.Rounded.FilterList,
                            onClick = { showCategoryFilterSheet = true },
                            tag = "filter_category_button"
                        )

                        // Date Range Chips
                        DateRangeFilter.entries.forEach { range ->
                            val isSelected = filters.dateRange == range
                            FilterPill(
                                label = range.label,
                                selected = isSelected,
                                leadingIcon = if (range == DateRangeFilter.CUSTOM) Icons.Rounded.CalendarMonth else null,
                                onClick = {
                                    if (range == DateRangeFilter.CUSTOM) {
                                        showCustomDateDialog = true
                                    } else {
                                        onDateRangeChange(range)
                                    }
                                },
                                tag = "filter_date_${range.name.lowercase()}"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Filtered Summary Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${filtered.size} record${if (filtered.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = spendlyColors.mutedText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "+${CurrencyFormatter.formatCompact(filteredIncome, symbol, indian)}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = MonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = spendlyColors.income
                            )
                            Text(
                                text = "-${CurrencyFormatter.formatCompact(filteredExpense, symbol, indian)}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = MonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = spendlyColors.expense
                            )
                        }
                    }
                }

                // Transaction List + Native Ads every 9 items
                if (listEntries.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        EmptyStateCard(
                            icon = Icons.Rounded.ReceiptLong,
                            title = if (filters.hasActiveFilters) "No matching transactions" else "Your ledger is empty",
                            subtitle = if (filters.hasActiveFilters) {
                                "Try clearing search terms or expanding the date/category filter."
                            } else {
                                "Tap the + button to log expenses or income in seconds."
                            },
                            actionLabel = if (filters.hasActiveFilters) "Clear Filters" else "Add Transaction",
                            onActionClick = if (filters.hasActiveFilters) onClearFilters else onAddTransaction
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = 4.dp,
                            bottom = 84.dp // Clear FAB comfortably
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listEntries.forEachIndexed { idx, entry ->
                            when (entry) {
                                is HistoryListEntry.DateHeader -> {
                                    item(key = "header_${entry.label}_$idx") {
                                        Text(
                                            text = entry.label,
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = spendlyColors.mutedText,
                                            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp, start = 4.dp)
                                        )
                                    }
                                }

                                is HistoryListEntry.TxItem -> {
                                    item(key = "tx_${entry.transaction.id}") {
                                        TransactionRowCard(
                                            transaction = entry.transaction,
                                            currencySymbol = symbol,
                                            indianNumbering = indian,
                                            onClick = { onEditTransaction(entry.transaction) },
                                            onDeleteClick = { pendingDeleteTx = entry.transaction }
                                        )
                                    }
                                }

                                is HistoryListEntry.NativeAdSlot -> {
                                    item(key = "native_ad_${entry.slotIndex}") {
                                        NativeTransactionAdCard(
                                            adUnitId = settings.adConfig.activeNativeId,
                                            nonPersonalizedOnly = settings.nonPersonalizedAdsOnly,
                                            slotKey = entry.slotIndex
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Floating Action Button positioned safely inside list Box (strictly ABOVE bottom banner ad)
            FloatingActionButton(
                onClick = onAddTransaction,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("transactions_add_fab")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = "Add transaction"
                )
            }
        }

        // Dedicated non-overlapping Banner Ad container on Transaction History screen
        AdaptiveBannerAd(
            adUnitId = settings.adConfig.activeHistoryBannerId,
            nonPersonalizedOnly = settings.nonPersonalizedAdsOnly,
            testTagName = "transactions_history_banner"
        )
    }

    // Category Filter Sheet
    if (showCategoryFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCategoryFilterSheet = false },
            containerColor = spendlyColors.cardSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Filter by Category",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (filters.categoryFilter != null) {
                        TextButton(
                            onClick = {
                                onCategoryFilterChange(null)
                                showCategoryFilterSheet = false
                            }
                        ) { Text("Clear") }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TransactionCategory.entries.forEach { cat ->
                        val isSelected = filters.categoryFilter == cat
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) cat.accentColor.copy(alpha = 0.22f)
                                    else spendlyColors.elevatedCard
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) cat.accentColor else spendlyColors.subtleBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    onCategoryFilterChange(if (isSelected) null else cat)
                                    showCategoryFilterSheet = false
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = cat.displayName,
                                tint = cat.accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = cat.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }

    // Custom Date Range Picker Dialog
    if (showCustomDateDialog) {
        val rangeState = rememberDateRangePickerState(
            initialSelectedStartDateMillis = filters.customStartMillis,
            initialSelectedEndDateMillis = filters.customEndMillis
        )
        DatePickerDialog(
            onDismissRequest = { showCustomDateDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val start = rangeState.selectedStartDateMillis
                        val end = rangeState.selectedEndDateMillis
                        if (start != null) {
                            // Include full end day up to 23:59:59
                            val inclusiveEnd = (end ?: start) + (24L * 60L * 60L * 1000L - 1L)
                            onCustomDateRangeSelected(start, inclusiveEnd)
                        }
                        showCustomDateDialog = false
                    }
                ) { Text("Apply") }
            },
            dismissButton = {
                TextButton(onClick = { showCustomDateDialog = false }) { Text("Cancel") }
            }
        ) {
            DateRangePicker(
                state = rangeState,
                modifier = Modifier.height(460.dp)
            )
        }
    }

    // Delete Confirmation Dialog
    val deleteTarget = pendingDeleteTx
    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { pendingDeleteTx = null },
            containerColor = spendlyColors.cardSurface,
            title = { Text("Delete Transaction?") },
            text = {
                Text(
                    "Remove this ${deleteTarget.transactionCategory.displayName} entry of " +
                        "${CurrencyFormatter.format(deleteTarget.amount, symbol, indian)}?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransaction(deleteTarget)
                        pendingDeleteTx = null
                    }
                ) {
                    Text("Delete", color = spendlyColors.expense)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteTx = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun FilterPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String,
    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    val spendlyColors = LocalSpendlyColors.current
    Row(
        modifier = Modifier
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else spendlyColors.cardSurface
            )
            .border(
                1.dp,
                if (selected) MaterialTheme.colorScheme.primary else spendlyColors.subtleBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else spendlyColors.mutedText,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) MaterialTheme.colorScheme.primary else spendlyColors.mutedText,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}
