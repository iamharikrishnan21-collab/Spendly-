package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.viewmodel.BudgetStatusItem
import kotlin.math.abs

/**
 * Refined category icon badge with tinted gradient fill, hairline accent border,
 * and optional directional income/expense mini-badge for crisp transaction scanning.
 */
@Composable
fun CategoryIconBadge(
    category: TransactionCategory,
    sizeDp: Int = 46,
    transactionType: TransactionType? = null,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    Box(modifier = modifier.size(sizeDp.dp)) {
        Box(
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(RoundedCornerShape((sizeDp * 0.32f).dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            category.accentColor.copy(alpha = 0.25f),
                            category.accentColor.copy(alpha = 0.09f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = category.accentColor.copy(alpha = 0.36f),
                    shape = RoundedCornerShape((sizeDp * 0.32f).dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = category.icon,
                contentDescription = category.displayName,
                tint = category.accentColor,
                modifier = Modifier.size((sizeDp * 0.50f).dp)
            )
        }

        if (transactionType != null) {
            val isIncome = transactionType == TransactionType.INCOME
            val badgeAccent = if (isIncome) spendlyColors.income else spendlyColors.expense
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 2.dp, y = 2.dp)
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(spendlyColors.cardSurface)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(badgeAccent),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isIncome) Icons.Rounded.ArrowDownward else Icons.Rounded.ArrowUpward,
                    contentDescription = if (isIncome) "Income" else "Expense",
                    tint = Color.White,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
    }
}

@Composable
fun TransactionRowCard(
    transaction: TransactionEntity,
    currencySymbol: String,
    indianNumbering: Boolean,
    onClick: () -> Unit,
    onDeleteClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val category = transaction.transactionCategory
    val isIncome = transaction.transactionType == TransactionType.INCOME
    val amountColor = if (isIncome) spendlyColors.income else spendlyColors.expense
    val formattedAmount = CurrencyFormatter.format(
        amount = if (isIncome) transaction.amount else -transaction.amount,
        symbol = currencySymbol,
        indianNumbering = indianNumbering,
        showPlusSign = true
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 68.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(spendlyColors.cardSurface)
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .semantics(mergeDescendants = true) {}
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("transaction_item_${transaction.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CategoryIconBadge(
            category = category,
            sizeDp = 46,
            transactionType = transaction.transactionType
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = category.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(category.accentColor.copy(alpha = 0.14f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isIncome) "IN" else "OUT",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = amountColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            val subtitle = buildString {
                if (transaction.note.isNotBlank()) {
                    append(transaction.note)
                    append(" • ")
                }
                append(DateUtils.formatTime(transaction.timestamp))
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = spendlyColors.mutedText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = formattedAmount,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = MonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = amountColor,
                maxLines = 1
            )
            Text(
                text = DateUtils.formatShortDay(transaction.timestamp),
                style = MaterialTheme.typography.labelSmall,
                color = spendlyColors.mutedText,
                maxLines = 1
            )
        }

        if (onDeleteClick != null) {
            Spacer(modifier = Modifier.width(2.dp))
            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("delete_transaction_${transaction.id}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete ${category.displayName} transaction",
                    tint = spendlyColors.mutedText
                )
            }
        }
    }
}

/**
 * Enhanced Monthly & Category Budget Card with spring-animated progress bar,
 * percentage badge, threshold marker, and clear Spent / Remaining / Limit stats.
 */
@Composable
fun BudgetProgressCard(
    item: BudgetStatusItem,
    currencySymbol: String,
    indianNumbering: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val animatedProgress by animateFloatAsState(
        targetValue = item.clampedProgress,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "budget_progress"
    )
    val accentColor = when {
        item.isExceeded -> spendlyColors.expense
        item.isWarning -> spendlyColors.warning
        else -> spendlyColors.income
    }
    val statusBadgeBg = when {
        item.isExceeded -> spendlyColors.expenseContainer
        item.isWarning -> spendlyColors.warningContainer
        else -> spendlyColors.incomeContainer
    }
    val statusLabel = when {
        item.isExceeded -> "Over budget"
        item.isWarning -> "Near limit"
        else -> "On track"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(spendlyColors.cardSurface)
            .border(
                width = 1.dp,
                color = if (item.isExceeded || item.isWarning) accentColor.copy(alpha = 0.45f)
                else spendlyColors.subtleBorder,
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onClick)
            .semantics(mergeDescendants = true) {}
            .padding(16.dp)
            .testTag("budget_card_${item.categoryName}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (item.category != null) {
                CategoryIconBadge(category = item.category, sizeDp = 42)
                Spacer(modifier = Modifier.width(12.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.displayTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(statusBadgeBg)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.isExceeded || item.isWarning) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = "Budget warning",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = "${item.percentUsed}% used",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = accentColor,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Animated progress bar with subtle warning threshold tick
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(CircleShape)
                .background(spendlyColors.elevatedCard)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedProgress)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(accentColor.copy(alpha = 0.85f), accentColor)
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Structured 3-stat financial breakdown: Spent | Remaining | Limit
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(spendlyColors.elevatedCard.copy(alpha = 0.72f))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BudgetStatColumn(
                label = "Spent",
                value = CurrencyFormatter.formatCompact(item.spentAmount, currencySymbol, indianNumbering),
                valueColor = MaterialTheme.colorScheme.onSurface,
                alignment = Alignment.Start,
                modifier = Modifier.weight(1f)
            )
            BudgetStatColumn(
                label = if (item.remainingAmount >= 0.0) "Remaining" else "Exceeded",
                value = CurrencyFormatter.formatCompact(abs(item.remainingAmount), currencySymbol, indianNumbering),
                valueColor = accentColor,
                alignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            )
            BudgetStatColumn(
                label = "Budget",
                value = CurrencyFormatter.formatCompact(item.limitAmount, currencySymbol, indianNumbering),
                valueColor = spendlyColors.mutedText,
                alignment = Alignment.End,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun BudgetStatColumn(
    label: String,
    value: String,
    valueColor: Color,
    alignment: Alignment.Horizontal,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    Column(
        modifier = modifier,
        horizontalAlignment = alignment
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = spendlyColors.mutedText,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall.copy(
                fontFamily = MonoFontFamily,
                fontWeight = FontWeight.Bold
            ),
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(spendlyColors.cardSurface)
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(22.dp))
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = spendlyColors.mutedText,
            textAlign = TextAlign.Center
        )
        if (actionLabel != null && onActionClick != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable(onClick = onActionClick)
                    .padding(horizontal = 22.dp, vertical = 12.dp)
                    .testTag("empty_state_action_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        if (actionLabel != null && onActionClick != null) {
            Box(
                modifier = Modifier
                    .heightIn(min = 40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onActionClick)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
