package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class SpendlyColors(
    val income: Color,
    val incomeContainer: Color,
    val expense: Color,
    val expenseContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val analyticsAccent: Color,
    val cardSurface: Color,
    val elevatedCard: Color,
    val subtleBorder: Color,
    val mutedText: Color,
    val isDark: Boolean
)

private val DarkSpendlyExtended = SpendlyColors(
    income = EmeraldPrimary,
    incomeContainer = EmeraldContainerDark,
    expense = CoralExpense,
    expenseContainer = CoralContainerDark,
    warning = AmberWarning,
    warningContainer = AmberContainerDark,
    analyticsAccent = SkyAnalytics,
    cardSurface = SlateCardSurface,
    elevatedCard = ElevatedCardSurface,
    subtleBorder = SubtleBorderDark,
    mutedText = TextMutedGrey,
    isDark = true
)

private val LightSpendlyExtended = SpendlyColors(
    income = EmeraldPrimaryLight,
    incomeContainer = EmeraldContainerLight,
    expense = CoralExpenseLight,
    expenseContainer = CoralContainerLight,
    warning = AmberWarningLight,
    warningContainer = AmberContainerLight,
    analyticsAccent = SkyAnalyticsLight,
    cardSurface = LightCardSurface,
    elevatedCard = LightElevatedSurface,
    subtleBorder = SubtleBorderLight,
    mutedText = TextDarkSecondary,
    isDark = false
)

val LocalSpendlyColors = staticCompositionLocalOf { DarkSpendlyExtended }

private val SpendlyDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = OnEmeraldDark,
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = EmeraldPrimary,
    secondary = SkyAnalytics,
    onSecondary = ObsidianBackground,
    secondaryContainer = SkyContainerDark,
    onSecondaryContainer = SkyAnalytics,
    tertiary = AmberWarning,
    onTertiary = ObsidianBackground,
    tertiaryContainer = AmberContainerDark,
    onTertiaryContainer = AmberWarning,
    background = ObsidianBackground,
    onBackground = TextWhitePrimary,
    surface = SlateCardSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = ElevatedCardSurface,
    onSurfaceVariant = TextMutedGrey,
    outline = SubtleBorderDark,
    outlineVariant = Color(0xFF1D2733),
    error = CoralExpense,
    onError = Color.White,
    errorContainer = CoralContainerDark,
    onErrorContainer = CoralExpense
)

private val SpendlyLightColorScheme = lightColorScheme(
    primary = EmeraldPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainerLight,
    onPrimaryContainer = Color(0xFF00523C),
    secondary = SkyAnalyticsLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF075985),
    tertiary = AmberWarningLight,
    onTertiary = Color.White,
    tertiaryContainer = AmberContainerLight,
    onTertiaryContainer = Color(0xFF7A4800),
    background = LightBackground,
    onBackground = TextDarkPrimary,
    surface = LightCardSurface,
    onSurface = TextDarkPrimary,
    surfaceVariant = LightElevatedSurface,
    onSurfaceVariant = TextDarkSecondary,
    outline = SubtleBorderLight,
    outlineVariant = Color(0xFFE6EDF5),
    error = CoralExpenseLight,
    onError = Color.White,
    errorContainer = CoralContainerLight,
    onErrorContainer = Color(0xFF8F122A)
)

@Composable
fun SpendlyTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SpendlyDarkColorScheme else SpendlyLightColorScheme
    val extendedColors = if (darkTheme) DarkSpendlyExtended else LightSpendlyExtended

    CompositionLocalProvider(LocalSpendlyColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = SpendlyTypography,
            content = content
        )
    }
}
