package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DonutLarge
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdMobManager
import com.example.data.model.TransactionType
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.IncomeVsExpenseChart
import com.example.ui.components.InteractiveExpenseBarChart
import com.example.ui.components.SavingsTrendChart
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.viewmodel.SpendlyUiState

private enum class ExpenseGranularity(val label: String) {
    DAILY("Daily"),
    WEEKLY("Weekly"),
    MONTHLY("Monthly")
}

@Composable
fun AnalyticsScreen(
    uiState: SpendlyUiState,
    onShiftMonth: (Int) -> Unit,
    onQuickAdd: (TransactionType) -> Unit,
    onRequestPremiumReportWithAd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val consentState by AdMobManager.consentState.collectAsStateWithLifecycle()
    val settings = uiState.settings
    val symbol = settings.currencySymbol
    val indian = settings.useIndianNumbering

    var granularity by remember { mutableStateOf(ExpenseGranularity.DAILY) }

    val savingsRate = remember(uiState.monthlyIncome, uiState.monthlySavings) {
        if (uiState.monthlyIncome > 0.0) {
            ((uiState.monthlySavings / uiState.monthlyIncome) * 100.0).toInt()
        } else 0
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header & Month Switcher (48dp accessible controls)
            item(key = "analytics_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Analytics",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onShiftMonth(-1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("analytics_prev_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronLeft,
                                contentDescription = "Previous month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = DateUtils.formatShortMonth(uiState.selectedMonthKey) +
                                " " + uiState.selectedMonthKey.take(4),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        IconButton(
                            onClick = { onShiftMonth(1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("analytics_next_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = "Next month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Dedicated, beautiful Analytics Empty State when there are no transactions yet
            if (uiState.allTransactions.isEmpty()) {
                item(key = "analytics_empty_hero") {
                    AnalyticsEmptyStateHero(
                        onAddExpense = { onQuickAdd(TransactionType.EXPENSE) },
                        onAddIncome = { onQuickAdd(TransactionType.INCOME) }
                    )
                }
            } else {
                // Monthly KPI Row
                item(key = "analytics_kpis") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AnalyticsKpiCard(
                            title = "Expense",
                            value = CurrencyFormatter.formatCompact(uiState.monthlyExpenses, symbol, indian),
                            accent = spendlyColors.expense,
                            modifier = Modifier.weight(1f)
                        )
                        AnalyticsKpiCard(
                            title = "Income",
                            value = CurrencyFormatter.formatCompact(uiState.monthlyIncome, symbol, indian),
                            accent = spendlyColors.income,
                            modifier = Modifier.weight(1f)
                        )
                        AnalyticsKpiCard(
                            title = "Savings",
                            value = "$savingsRate%",
                            accent = if (savingsRate >= 0) spendlyColors.analyticsAccent else spendlyColors.expense,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // 1. Daily / Weekly / Monthly Expenses Interactive Chart
                item(key = "expense_trends_card") {
                    AnalyticsChartContainer(
                        title = "Expense Breakdown",
                        subtitle = when (granularity) {
                            ExpenseGranularity.DAILY -> "Last 14 days — tap any bar to inspect"
                            ExpenseGranularity.WEEKLY -> "Last 8 weeks — tap any bar to inspect"
                            ExpenseGranularity.MONTHLY -> "Last 6 months — tap any bar to inspect"
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(spendlyColors.elevatedCard)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            ExpenseGranularity.entries.forEach { tab ->
                                val isSelected = granularity == tab
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primary
                                            else Color.Transparent
                                        )
                                        .clickable { granularity = tab }
                                        .testTag("analytics_period_${tab.name.lowercase()}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else spendlyColors.mutedText,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val activePoints = when (granularity) {
                            ExpenseGranularity.DAILY -> uiState.dailyExpenses
                            ExpenseGranularity.WEEKLY -> uiState.weeklyExpenses
                            ExpenseGranularity.MONTHLY -> uiState.monthlyExpensesSeries
                        }

                        InteractiveExpenseBarChart(
                            points = activePoints,
                            currencySymbol = symbol,
                            indianNumbering = indian,
                            barColor = spendlyColors.expense
                        )
                    }
                }

                // 2. Category-wise Spending Donut Chart
                item(key = "category_donut_card") {
                    AnalyticsChartContainer(
                        title = "Category-wise Spending",
                        subtitle = "Tap any slice or row to inspect share"
                    ) {
                        if (uiState.categoryBreakdown.isEmpty()) {
                            EmptyStateCard(
                                icon = Icons.Rounded.Insights,
                                title = "No expenses logged yet",
                                subtitle = "Add an expense to see your interactive category breakdown.",
                                actionLabel = "Add Expense",
                                onActionClick = { onQuickAdd(TransactionType.EXPENSE) }
                            )
                        } else {
                            CategoryDonutChart(
                                slices = uiState.categoryBreakdown,
                                currencySymbol = symbol,
                                indianNumbering = indian
                            )
                        }
                    }
                }

                // 3. Income vs Expenses Chart
                item(key = "income_vs_expense_card") {
                    AnalyticsChartContainer(
                        title = "Income vs Expenses",
                        subtitle = "6-month cash flow comparison"
                    ) {
                        IncomeVsExpenseChart(
                            series = uiState.incomeVsExpenseSeries,
                            currencySymbol = symbol,
                            indianNumbering = indian
                        )
                    }
                }

                // 4. Savings Trends Chart
                item(key = "savings_trend_card") {
                    AnalyticsChartContainer(
                        title = "Savings Trends",
                        subtitle = "Net monthly savings trajectory"
                    ) {
                        SavingsTrendChart(
                            points = uiState.savingsTrendSeries,
                            currencySymbol = symbol,
                            indianNumbering = indian
                        )
                    }
                }

                // 5. Optional Rewarded Ad — Premium Detailed Financial Report Export
                item(key = "premium_report_card") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(spendlyColors.cardSurface)
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                RoundedCornerShape(22.dp)
                            )
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Assessment,
                                    contentDescription = "Premium report",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Detailed Financial Report",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Includes executive summary, savings rate, category shares & full ledger",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = spendlyColors.mutedText
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = onRequestPremiumReportWithAd,
                            enabled = !consentState.isRewardedAdLoading,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 50.dp)
                                .testTag("rewarded_premium_report_button")
                        ) {
                            if (consentState.isRewardedAdLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Loading Ad…")
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.PlayCircleOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Watch Short Ad to Export Report",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Optional rewarded ad • Standard CSV export is always available offline in Settings",
                            style = MaterialTheme.typography.labelSmall,
                            color = spendlyColors.mutedText
                        )
                    }
                }
            }

            item(key = "analytics_bottom_space") { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

/**
 * Premium dark-fintech Analytics Empty State displayed when no transactions exist yet.
 * Features an animated glowing chart artwork, live preview pills of unlocked charts,
 * and working quick-add buttons for Expense and Income.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AnalyticsEmptyStateHero(
    onAddExpense: () -> Unit,
    onAddIncome: () -> Unit
) {
    val spendlyColors = LocalSpendlyColors.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = spendlyColors.analyticsAccent
    val expenseColor = spendlyColors.expense

    val pulseTransition = rememberInfiniteTransition(label = "analytics_empty_pulse")
    val barPulse by pulseTransition.animateFloat(
        initialValue = 0.86f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar_pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(spendlyColors.cardSurface)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = if (spendlyColors.isDark) 0.16f else 0.09f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.18f),
                        radius = size.width * 0.65f
                    ),
                    radius = size.width * 0.65f,
                    center = Offset(size.width * 0.5f, size.height * 0.18f)
                )
            }
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(26.dp))
            .padding(horizontal = 20.dp, vertical = 26.dp)
            .testTag("analytics_empty_state"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Stylized Fintech Chart Illustration
        Box(
            modifier = Modifier
                .size(136.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(spendlyColors.elevatedCard.copy(alpha = 0.85f))
                .border(1.dp, primaryColor.copy(alpha = 0.28f), RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(92.dp)) {
                val barWeights = listOf(0.38f, 0.62f, 0.48f, 0.82f, 0.70f)
                val barCount = barWeights.size
                val gap = 7.dp.toPx()
                val totalGap = gap * (barCount - 1)
                val barW = (size.width - totalGap) / barCount
                val bottomY = size.height * 0.86f
                val maxBarH = size.height * 0.62f

                barWeights.forEachIndexed { idx, w ->
                    val dynamicScale = if (idx % 2 == 0) barPulse else (1.86f - barPulse)
                    val h = (maxBarH * w * dynamicScale).coerceAtMost(maxBarH)
                    val left = idx * (barW + gap)
                    val color = when (idx) {
                        3 -> primaryColor
                        4 -> secondaryColor
                        else -> primaryColor.copy(alpha = 0.35f)
                    }
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(left, bottomY - h),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx())
                    )
                }

                // Smooth emerald trend curve overlay
                val linePath = Path().apply {
                    moveTo(4.dp.toPx(), size.height * 0.56f)
                    cubicTo(
                        size.width * 0.30f, size.height * 0.32f,
                        size.width * 0.58f, size.height * 0.46f,
                        size.width - 4.dp.toPx(), size.height * 0.16f
                    )
                }
                drawPath(
                    path = linePath,
                    color = primaryColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
                drawCircle(
                    color = primaryColor,
                    radius = 5.dp.toPx(),
                    center = Offset(size.width - 4.dp.toPx(), size.height * 0.16f)
                )
                drawCircle(
                    color = spendlyColors.cardSurface,
                    radius = 2.2.dp.toPx(),
                    center = Offset(size.width - 4.dp.toPx(), size.height * 0.16f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Your Financial Insights Await",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Charts and trends update automatically the moment you log your first expense or income — 100% private and offline.",
            style = MaterialTheme.typography.bodyMedium,
            color = spendlyColors.mutedText,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Feature preview badges of unlocked analytics charts
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            AnalyticsPreviewBadge(Icons.Rounded.BarChart, "Daily & Monthly", expenseColor)
            AnalyticsPreviewBadge(Icons.Rounded.DonutLarge, "Category Share", secondaryColor)
            AnalyticsPreviewBadge(Icons.Rounded.SwapVert, "Income vs Expense", primaryColor)
            AnalyticsPreviewBadge(Icons.Rounded.ShowChart, "Savings Trends", primaryColor)
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Real working CTA buttons right inside the empty state
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onAddExpense,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = spendlyColors.expenseContainer,
                    contentColor = spendlyColors.expense
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    spendlyColors.expense.copy(alpha = 0.45f)
                ),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 50.dp)
                    .testTag("analytics_empty_add_expense")
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Add Expense",
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Button(
                onClick = onAddIncome,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 50.dp)
                    .testTag("analytics_empty_add_income")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Add Income",
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun AnalyticsPreviewBadge(
    icon: ImageVector,
    label: String,
    accent: Color
) {
    val spendlyColors = LocalSpendlyColors.current
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(spendlyColors.elevatedCard)
            .border(1.dp, spendlyColors.subtleBorder, CircleShape)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun AnalyticsKpiCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(spendlyColors.cardSurface)
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(18.dp))
            .semantics(mergeDescendants = true) {}
            .padding(horizontal = 10.dp, vertical = 14.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = spendlyColors.mutedText,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = MonoFontFamily,
                fontWeight = FontWeight.Bold
            ),
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AnalyticsChartContainer(
    title: String,
    subtitle: String,
    content: @Composable () -> Unit
) {
    val spendlyColors = LocalSpendlyColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(spendlyColors.cardSurface)
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = spendlyColors.mutedText
        )
        Spacer(modifier = Modifier.height(14.dp))
        content()
    }
}
