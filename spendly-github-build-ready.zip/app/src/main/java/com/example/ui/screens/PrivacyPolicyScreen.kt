package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalSpendlyColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val spendlyColors = LocalSpendlyColors.current

    val sections = listOf(
        "1. Offline-First Local Storage" to
            "Spendly is designed as an offline-first personal finance manager. All transactions, notes, categories, and budgets you create are stored locally on your device in an on-device SQLite database (Room) and Preferences store. Spendly does not require account registration, login, or cloud upload of your financial ledger.",
        "2. Data Export, Backup & Restore" to
            "When you export transactions to CSV, generate a detailed report, or create a local JSON backup, Spendly uses Android's built-in Storage Access Framework (SAF). You choose the exact folder or destination. Spendly never scans or accesses unrelated files on your device.",
        "3. Budget Warning Notifications" to
            "If you enable budget warning alerts, Spendly evaluates your local spending against your local monthly and category budgets directly on-device and posts local Android notifications when thresholds are reached.",
        "4. Google AdMob & Consent" to
            "Spendly integrates Google Mobile Ads (AdMob) to support free usage through non-intrusive banners, native feed cards, and optional user-requested rewarded ads. Advertisements require an active internet connection; all expense management features continue working 100% offline without ads.\n\nGoogle AdMob may collect device identifiers and diagnostic signals in accordance with Google's Privacy Policy and your consent choices. You can manage ad consent preferences or enable Non-Personalized Ads Only anytime in Settings.",
        "5. Full Control & Data Deletion" to
            "Because your financial data lives strictly on your device, you remain in full control. You can edit or delete individual entries at any time, or permanently wipe all local transactions and budgets using Settings → Delete All Data."
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Privacy Policy",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("privacy_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item(key = "policy_intro") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Your Financial Data Stays Yours",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "No login required. No remote financial server. Spendly works completely offline for tracking expenses, income, budgets, and analytics.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                sections.forEachIndexed { idx, (heading, body) ->
                    item(key = "policy_section_$idx") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(spendlyColors.cardSurface)
                                .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(20.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = heading,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = body,
                                style = MaterialTheme.typography.bodyMedium,
                                color = spendlyColors.mutedText
                            )
                        }
                    }
                }

                item(key = "policy_footer") {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
