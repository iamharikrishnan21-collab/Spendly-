package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Spendly Signature Dark Fintech Palette
val ObsidianBackground = Color(0xFF0B0F14)
val SlateCardSurface = Color(0xFF151C24)
val ElevatedCardSurface = Color(0xFF1C2530)
val SubtleBorderDark = Color(0xFF253140)

val EmeraldPrimary = Color(0xFF00D09C)
val EmeraldDim = Color(0xFF00A87E)
val EmeraldContainerDark = Color(0xFF0A2E26)
val OnEmeraldDark = Color(0xFF022017)

val CoralExpense = Color(0xFFFF5C77)
val CoralContainerDark = Color(0xFF33151E)

val AmberWarning = Color(0xFFFFB547)
val AmberContainerDark = Color(0xFF332612)

val SkyAnalytics = Color(0xFF38BDF8)
val SkyContainerDark = Color(0xFF0E2938)

val TextWhitePrimary = Color(0xFFF4F7FA)
val TextMutedGrey = Color(0xFF8E9BAE)
val TextSubtleGrey = Color(0xFF637083)

// Spendly Crisp Light Fintech Palette (Optional Light Mode Toggle)
val LightBackground = Color(0xFFF4F7FA)
val LightCardSurface = Color(0xFFFFFFFF)
val LightElevatedSurface = Color(0xFFEAF0F6)
val SubtleBorderLight = Color(0xFFD8E1EC)

val EmeraldPrimaryLight = Color(0xFF00A87E)
val EmeraldContainerLight = Color(0xFFD9F7EE)
val CoralExpenseLight = Color(0xFFE03A58)
val CoralContainerLight = Color(0xFFFFE5EA)
val AmberWarningLight = Color(0xFFD98600)
val AmberContainerLight = Color(0xFFFFF2DB)
val SkyAnalyticsLight = Color(0xFF0284C7)

val TextDarkPrimary = Color(0xFF0E1722)
val TextDarkSecondary = Color(0xFF56657A)
