package com.example.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.DateUtils
import java.util.Calendar

/**
 * Ad-free, distraction-free bottom sheet for adding or editing a transaction.
 * Strictly obeys AdMob UX rule: never interrupt adding or editing transactions.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTransactionSheet(
    initialType: TransactionType,
    existingTransaction: TransactionEntity?,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (
        existingId: Long?,
        amount: Double,
        type: TransactionType,
        category: TransactionCategory,
        note: String,
        timestamp: Long
    ) -> Unit,
    onDelete: ((TransactionEntity) -> Unit)? = null
) {
    val context = LocalContext.current
    val spendlyColors = LocalSpendlyColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val initialCal = remember(existingTransaction) {
        Calendar.getInstance().apply {
            if (existingTransaction != null) timeInMillis = existingTransaction.timestamp
        }
    }

    var selectedType by remember(existingTransaction, initialType) {
        mutableStateOf(existingTransaction?.transactionType ?: initialType)
    }
    var amountText by remember(existingTransaction) {
        mutableStateOf(
            existingTransaction?.amount?.let {
                if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
            } ?: ""
        )
    }
    var selectedCategory by remember(existingTransaction, initialType) {
        mutableStateOf(
            existingTransaction?.transactionCategory
                ?: if (initialType == TransactionType.INCOME) TransactionCategory.SALARY else TransactionCategory.FOOD
        )
    }
    var noteText by remember(existingTransaction) {
        mutableStateOf(existingTransaction?.note ?: "")
    }
    var selectedDateMillis by remember(existingTransaction) {
        mutableLongStateOf(initialCal.timeInMillis)
    }
    var selectedHour by remember(existingTransaction) {
        mutableIntStateOf(initialCal.get(Calendar.HOUR_OF_DAY))
    }
    var selectedMinute by remember(existingTransaction) {
        mutableIntStateOf(initialCal.get(Calendar.MINUTE))
    }
    var amountError by remember { mutableStateOf<String?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    val combinedTimestamp = remember(selectedDateMillis, selectedHour, selectedMinute) {
        DateUtils.combineDateAndTime(selectedDateMillis, selectedHour, selectedMinute)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = spendlyColors.cardSurface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (existingTransaction == null) "New Transaction" else "Edit Transaction",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("close_transaction_sheet")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = spendlyColors.mutedText
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Expense / Income Segmented Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(spendlyColors.elevatedCard)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TransactionType.entries.forEach { type ->
                    val isSelected = selectedType == type
                    val activeColor = if (type == TransactionType.INCOME) {
                        spendlyColors.income
                    } else {
                        spendlyColors.expense
                    }
                    val activeTextColor = if (type == TransactionType.INCOME) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        Color.White
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) activeColor else Color.Transparent)
                            .clickable {
                                selectedType = type
                                if (existingTransaction == null) {
                                    if (type == TransactionType.INCOME &&
                                        selectedCategory !in TransactionCategory.incomeCategories()
                                    ) {
                                        selectedCategory = TransactionCategory.SALARY
                                    } else if (type == TransactionType.EXPENSE &&
                                        selectedCategory == TransactionCategory.SALARY
                                    ) {
                                        selectedCategory = TransactionCategory.FOOD
                                    }
                                }
                            }
                            .testTag("type_toggle_${type.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = type.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isSelected) activeTextColor else spendlyColors.mutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Amount Input
            OutlinedTextField(
                value = amountText,
                onValueChange = { input ->
                    val filtered = input.filter { it.isDigit() || it == '.' }
                    val dotCount = filtered.count { it == '.' }
                    val parts = filtered.split('.')
                    val validDecimals = parts.size <= 1 || parts[1].length <= 2
                    if (dotCount <= 1 && validDecimals && filtered.length <= 12) {
                        amountText = filtered
                        amountError = null
                    }
                },
                label = { Text("Amount ($currencySymbol)") },
                prefix = {
                    Text(
                        text = "$currencySymbol ",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = MonoFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (selectedType == TransactionType.INCOME) {
                            spendlyColors.income
                        } else {
                            spendlyColors.expense
                        }
                    )
                },
                textStyle = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = MonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                singleLine = true,
                isError = amountError != null,
                supportingText = amountError?.let { msg -> { Text(msg) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = spendlyColors.subtleBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Selection (All 11 Categories)
            Text(
                text = "Category",
                style = MaterialTheme.typography.titleSmall,
                color = spendlyColors.mutedText
            )
            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransactionCategory.entries.forEach { category ->
                    val isSelected = selectedCategory == category
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) category.accentColor.copy(alpha = 0.22f)
                                else spendlyColors.elevatedCard
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) category.accentColor else spendlyColors.subtleBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedCategory = category }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("category_chip_${category.name.lowercase()}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.displayName,
                            tint = if (isSelected) category.accentColor else spendlyColors.mutedText,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = category.displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) MaterialTheme.colorScheme.onSurface else spendlyColors.mutedText,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Date & Time Selectors
            Text(
                text = "Date & Time",
                style = MaterialTheme.typography.titleSmall,
                color = spendlyColors.mutedText
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(spendlyColors.elevatedCard)
                        .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp))
                        .clickable { showDatePicker = true }
                        .padding(horizontal = 12.dp)
                        .testTag("select_date_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarToday,
                        contentDescription = "Select date",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = DateUtils.formatFullDate(combinedTimestamp),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    modifier = Modifier
                        .weight(0.85f)
                        .height(50.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(spendlyColors.elevatedCard)
                        .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp))
                        .clickable {
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    selectedHour = hourOfDay
                                    selectedMinute = minute
                                },
                                selectedHour,
                                selectedMinute,
                                false
                            ).show()
                        }
                        .padding(horizontal = 12.dp)
                        .testTag("select_time_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AccessTime,
                        contentDescription = "Select time",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = DateUtils.formatTime(combinedTimestamp),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Notes Input
            OutlinedTextField(
                value = noteText,
                onValueChange = { if (it.length <= 200) noteText = it },
                label = { Text("Note (optional)") },
                placeholder = { Text("e.g., Lunch with team, Electricity bill, Freelance invoice") },
                maxLines = 3,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = spendlyColors.subtleBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_input")
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Save & Optional Delete Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (existingTransaction != null && onDelete != null) {
                    OutlinedButton(
                        onClick = { onDelete(existingTransaction) },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = spendlyColors.expense),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("delete_existing_transaction_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete transaction"
                        )
                    }
                }

                Button(
                    onClick = {
                        val parsed = amountText.toDoubleOrNull()
                        if (parsed == null || !parsed.isFinite() || parsed <= 0.0) {
                            amountError = "Enter an amount greater than 0"
                        } else {
                            onSave(
                                existingTransaction?.id,
                                parsed,
                                selectedType,
                                selectedCategory,
                                noteText,
                                combinedTimestamp
                            )
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("save_transaction_button")
                ) {
                    Text(
                        text = if (existingTransaction == null) "Save ${selectedType.label}" else "Update Transaction",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { selectedDateMillis = it }
                        showDatePicker = false
                    }
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
