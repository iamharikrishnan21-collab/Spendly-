package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdMobManager
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.screens.AddEditTransactionSheet
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BudgetsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PrivacyPolicyScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.theme.LocalSpendlyColors
import com.example.util.BudgetNotificationHelper
import com.example.util.DateUtils
import com.example.viewmodel.SpendlyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SpendlyTab(
    val routeId: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("dashboard", "Dashboard", Icons.Rounded.Dashboard, Icons.Outlined.Dashboard),
    TRANSACTIONS("transactions", "Transactions", Icons.Rounded.ReceiptLong, Icons.Outlined.ReceiptLong),
    BUDGETS("budgets", "Budgets", Icons.Rounded.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    ANALYTICS("analytics", "Analytics", Icons.Rounded.Insights, Icons.Outlined.Insights)
}

private enum class SecondaryScreen {
    NONE,
    SETTINGS,
    PRIVACY_POLICY
}

private enum class ExportKind {
    CSV,
    PREMIUM_REPORT,
    JSON_BACKUP
}

@Composable
fun SpendlyApp(
    viewModel: SpendlyViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val spendlyColors = LocalSpendlyColors.current

    var currentTab by remember { mutableStateOf(SpendlyTab.DASHBOARD) }
    var secondaryScreen by remember { mutableStateOf(SecondaryScreen.NONE) }

    // Add/Edit Transaction bottom sheet state
    var showTransactionSheet by remember { mutableStateOf(false) }
    var sheetInitialType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var editingTransaction by remember { mutableStateOf<TransactionEntity?>(null) }

    // SAF export / restore pending state
    var pendingExportKind by remember { mutableStateOf<ExportKind?>(null) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }

    // Collect ViewModel snackbar feedback
    LaunchedEffect(Unit) {
        viewModel.snackbarMessages.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Runtime notification permission launcher (Android 13+) for Budget Warning Notifications
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            BudgetNotificationHelper.ensureChannel(context)
            viewModel.setBudgetWarningsEnabled(true)
            viewModel.emitMessage("Budget warning notifications enabled")
        } else {
            viewModel.setBudgetWarningsEnabled(true)
            viewModel.emitMessage("In-app budget alerts active (system notifications denied)")
        }
    }

    // Storage Access Framework (zero storage permissions!) — Create CSV / Report / Backup JSON
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val kind = pendingExportKind
        pendingExportKind = null
        if (uri == null || kind == null) return@rememberLauncherForActivityResult

        coroutineScope.launch {
            runCatching {
                val payload = when (kind) {
                    ExportKind.CSV -> viewModel.buildCsvExport()
                    ExportKind.PREMIUM_REPORT -> viewModel.buildPremiumReportExport()
                    ExportKind.JSON_BACKUP -> viewModel.buildBackupJson()
                }
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write(payload.toByteArray(Charsets.UTF_8))
                    } ?: error("Unable to open destination file.")
                }
            }.onSuccess {
                val msg = when (kind) {
                    ExportKind.CSV -> "Transactions exported to CSV"
                    ExportKind.PREMIUM_REPORT -> "Detailed Financial Report exported"
                    ExportKind.JSON_BACKUP -> "Local backup JSON saved"
                }
                viewModel.emitMessage(msg)
            }.onFailure { err ->
                viewModel.emitMessage(err.message ?: "Export failed")
            }
        }
    }

    // Storage Access Framework — Open JSON backup file for Restore
    val openBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        coroutineScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Could not read selected file.")
                }
            }.onSuccess { jsonText ->
                pendingRestoreJson = jsonText
            }.onFailure { err ->
                viewModel.emitMessage(err.message ?: "Unable to read backup file.")
            }
        }
    }

    fun launchExport(kind: ExportKind) {
        pendingExportKind = kind
        val stamp = DateUtils.fileTimestamp()
        val fileName = when (kind) {
            ExportKind.CSV -> "spendly_transactions_$stamp.csv"
            ExportKind.PREMIUM_REPORT -> "spendly_detailed_report_$stamp.csv"
            ExportKind.JSON_BACKUP -> "spendly_backup_$stamp.json"
        }
        createDocumentLauncher.launch(fileName)
    }

    // Render Settings or Privacy Policy full-screen overlays when active
    when (secondaryScreen) {
        SecondaryScreen.SETTINGS -> {
            SettingsScreen(
                settings = uiState.settings,
                transactionCount = uiState.allTransactions.size,
                onBack = { secondaryScreen = SecondaryScreen.NONE },
                onToggleDarkMode = viewModel::setDarkMode,
                onSelectCurrency = viewModel::setCurrencySymbol,
                onToggleIndianNumbering = viewModel::setIndianNumbering,
                onToggleBudgetWarnings = { enable ->
                    if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        !BudgetNotificationHelper.hasNotificationPermission(context)
                    ) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        viewModel.setBudgetWarningsEnabled(enable)
                    }
                },
                onSelectWarningThreshold = viewModel::setWarningThresholdPercent,
                onExportCsv = { launchExport(ExportKind.CSV) },
                onBackupData = { launchExport(ExportKind.JSON_BACKUP) },
                onRestoreData = { openBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                onDeleteAllData = viewModel::deleteAllData,
                onToggleNonPersonalizedAds = viewModel::setNonPersonalizedAdsOnly,
                onOpenAdPrivacyOptions = {
                    if (activity != null) {
                        AdMobManager.showPrivacyOptionsForm(activity) { msg ->
                            viewModel.emitMessage(msg)
                        }
                    }
                },
                onUpdateAdConfig = viewModel::updateAdConfig,
                onOpenPrivacyPolicy = { secondaryScreen = SecondaryScreen.PRIVACY_POLICY }
            )
        }

        SecondaryScreen.PRIVACY_POLICY -> {
            PrivacyPolicyScreen(
                onBack = { secondaryScreen = SecondaryScreen.SETTINGS }
            )
        }

        SecondaryScreen.NONE -> {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavigationRail = maxWidth >= 600.dp

                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    bottomBar = {
                        if (!useNavigationRail) {
                            NavigationBar(
                                containerColor = spendlyColors.cardSurface,
                                tonalElevation = 0.dp
                            ) {
                                SpendlyTab.entries.forEach { tab ->
                                    val selected = currentTab == tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { currentTab = tab },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = tab.label,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = MaterialTheme.colorScheme.primary,
                                            selectedTextColor = MaterialTheme.colorScheme.primary,
                                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                            unselectedIconColor = spendlyColors.mutedText,
                                            unselectedTextColor = spendlyColors.mutedText
                                        ),
                                        modifier = Modifier.testTag("nav_tab_${tab.routeId}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (useNavigationRail) {
                            NavigationRail(
                                containerColor = spendlyColors.cardSurface
                            ) {
                                Spacer(modifier = Modifier.weight(0.15f))
                                SpendlyTab.entries.forEach { tab ->
                                    val selected = currentTab == tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { currentTab = tab },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        },
                                        label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = MaterialTheme.colorScheme.primary,
                                            selectedTextColor = MaterialTheme.colorScheme.primary,
                                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                            unselectedIconColor = spendlyColors.mutedText,
                                            unselectedTextColor = spendlyColors.mutedText
                                        ),
                                        modifier = Modifier.testTag("nav_rail_${tab.routeId}")
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }

                        Crossfade(
                            targetState = currentTab,
                            label = "main_tab_crossfade",
                            modifier = Modifier.weight(1f)
                        ) { tab ->
                            when (tab) {
                                SpendlyTab.DASHBOARD -> DashboardScreen(
                                    uiState = uiState,
                                    onShiftMonth = viewModel::shiftSelectedMonth,
                                    onResetToCurrentMonth = viewModel::resetToCurrentMonth,
                                    onQuickAdd = { type ->
                                        editingTransaction = null
                                        sheetInitialType = type
                                        showTransactionSheet = true
                                    },
                                    onEditTransaction = { tx ->
                                        editingTransaction = tx
                                        sheetInitialType = tx.transactionType
                                        showTransactionSheet = true
                                    },
                                    onOpenTransactions = { currentTab = SpendlyTab.TRANSACTIONS },
                                    onOpenBudgets = { currentTab = SpendlyTab.BUDGETS },
                                    onOpenAnalytics = { currentTab = SpendlyTab.ANALYTICS },
                                    onOpenSettings = { secondaryScreen = SecondaryScreen.SETTINGS }
                                )

                                SpendlyTab.TRANSACTIONS -> TransactionsScreen(
                                    uiState = uiState,
                                    onSearchChange = viewModel::updateSearchQuery,
                                    onTypeFilterChange = viewModel::updateTypeFilter,
                                    onCategoryFilterChange = viewModel::updateCategoryFilter,
                                    onDateRangeChange = viewModel::updateDateRangeFilter,
                                    onCustomDateRangeSelected = viewModel::setCustomDateRange,
                                    onClearFilters = viewModel::clearFilters,
                                    onAddTransaction = {
                                        editingTransaction = null
                                        sheetInitialType = TransactionType.EXPENSE
                                        showTransactionSheet = true
                                    },
                                    onEditTransaction = { tx ->
                                        editingTransaction = tx
                                        sheetInitialType = tx.transactionType
                                        showTransactionSheet = true
                                    },
                                    onDeleteTransaction = viewModel::deleteTransaction
                                )

                                SpendlyTab.BUDGETS -> BudgetsScreen(
                                    uiState = uiState,
                                    onShiftMonth = viewModel::shiftSelectedMonth,
                                    onSaveBudget = viewModel::saveBudget,
                                    onRemoveBudget = viewModel::removeBudget
                                )

                                SpendlyTab.ANALYTICS -> AnalyticsScreen(
                                    uiState = uiState,
                                    onShiftMonth = viewModel::shiftSelectedMonth,
                                    onQuickAdd = { type ->
                                        editingTransaction = null
                                        sheetInitialType = type
                                        showTransactionSheet = true
                                    },
                                    onRequestPremiumReportWithAd = {
                                        if (activity == null) {
                                            viewModel.emitMessage("Unable to open rewarded ad.")
                                        } else {
                                            AdMobManager.loadAndShowRewardedAd(
                                                activity = activity,
                                                adUnitId = uiState.settings.adConfig.activeRewardedId,
                                                nonPersonalizedOnly = uiState.settings.nonPersonalizedAdsOnly,
                                                onRewardEarned = {
                                                    launchExport(ExportKind.PREMIUM_REPORT)
                                                },
                                                onMessage = { msg -> viewModel.emitMessage(msg) }
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Ad-Free Add / Edit Transaction Modal Sheet
    if (showTransactionSheet) {
        AddEditTransactionSheet(
            initialType = sheetInitialType,
            existingTransaction = editingTransaction,
            currencySymbol = uiState.settings.currencySymbol,
            onDismiss = {
                showTransactionSheet = false
                editingTransaction = null
            },
            onSave = { id, amount, type, category, note, timestamp ->
                viewModel.saveTransaction(id, amount, type, category, note, timestamp)
                showTransactionSheet = false
                editingTransaction = null
            },
            onDelete = if (editingTransaction != null) { tx ->
                viewModel.deleteTransaction(tx)
                showTransactionSheet = false
                editingTransaction = null
            } else null
        )
    }

    // Restore Mode Confirmation Dialog (Merge vs Replace Existing)
    val restoreJson = pendingRestoreJson
    if (restoreJson != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreJson = null },
            containerColor = spendlyColors.cardSurface,
            title = { Text("Restore Spendly Backup") },
            text = {
                Text("Choose whether to merge backup records with your current data or replace all existing local data.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.restoreBackup(restoreJson, replaceExisting = false)
                        pendingRestoreJson = null
                    }
                ) {
                    Text("Merge", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            viewModel.restoreBackup(restoreJson, replaceExisting = true)
                            pendingRestoreJson = null
                        }
                    ) {
                        Text("Replace All", color = spendlyColors.expense)
                    }
                    TextButton(onClick = { pendingRestoreJson = null }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
