package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdaptiveBannerAd
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.BudgetProgressCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.IncomeVsExpenseChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.viewmodel.SpendlyUiState

@Composable
fun DashboardScreen(
    uiState: SpendlyUiState,
    onShiftMonth: (Int) -> Unit,
    onResetToCurrentMonth: () -> Unit,
    onQuickAdd: (TransactionType) -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onOpenTransactions: () -> Unit,
    onOpenBudgets: () -> Unit,
    onOpenAnalytics: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    val settings = uiState.settings
    val symbol = settings.currencySymbol
    val indian = settings.useIndianNumbering
    val isCurrentMonth = uiState.selectedMonthKey == DateUtils.currentMonthKey()

    var isQuickFabExpanded by remember { mutableStateOf(false) }
    val fabRotation by animateFloatAsState(
        targetValue = if (isQuickFabExpanded) 45f else 0f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f),
        label = "dashboard_fab_rotation"
    )

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Primary scrollable dashboard + Floating Quick-Add FAB strictly ABOVE the docked banner ad
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 14.dp,
                    bottom = 92.dp // Generous clearance so Floating Quick-Add FAB never covers cards
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Top Bar Header with Settings button
                item(key = "header") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Spendly",
                                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onBackground,
                                    maxLines = 1
                                )
                            }
                            Text(
                                text = "Offline Financial Overview",
                                style = MaterialTheme.typography.bodySmall,
                                color = spendlyColors.mutedText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(spendlyColors.cardSurface)
                                .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(14.dp))
                                .testTag("open_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Open settings",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Dashboard Month Selector Bar (Responsive, 48dp accessible controls)
                item(key = "dashboard_month_selector") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(16.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onShiftMonth(-1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("dashboard_prev_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronLeft,
                                contentDescription = "Previous month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(enabled = !isCurrentMonth, onClick = onResetToCurrentMonth)
                                .padding(vertical = 6.dp)
                                .testTag("dashboard_month_label")
                        ) {
                            Text(
                                text = DateUtils.formatMonthLabel(uiState.selectedMonthKey),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!isCurrentMonth) {
                                Text(
                                    text = "Tap for current month",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        IconButton(
                            onClick = { onShiftMonth(1) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("dashboard_next_month")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = "Next month",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Active Budget Warning Banner (if any budget >= threshold)
                if (uiState.activeBudgetWarnings.isNotEmpty()) {
                    item(key = "budget_warnings") {
                        val primaryWarning = uiState.activeBudgetWarnings.first()
                        val warnColor = if (primaryWarning.isExceeded) spendlyColors.expense else spendlyColors.warning
                        val warnBg = if (primaryWarning.isExceeded) spendlyColors.expenseContainer else spendlyColors.warningContainer
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(warnBg)
                                .border(1.dp, warnColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                .clickable(onClick = onOpenBudgets)
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                .testTag("dashboard_budget_warning_banner"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WarningAmber,
                                contentDescription = "Budget warning",
                                tint = warnColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (primaryWarning.isExceeded) {
                                        "${primaryWarning.displayTitle} exceeded (${primaryWarning.percentUsed}%)"
                                    } else {
                                        "${primaryWarning.displayTitle} reached ${primaryWarning.percentUsed}%"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = warnColor
                                )
                                if (uiState.activeBudgetWarnings.size > 1) {
                                    Text(
                                        text = "+${uiState.activeBudgetWarnings.size - 1} more budget alert(s) • Tap to review",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Hero Balance Card with Atmospheric Emerald Radial Glow
                item(key = "hero_balance") {
                    val glowColor = MaterialTheme.colorScheme.primary
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val isCompactWidth = maxWidth < 360.dp
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(26.dp))
                                .background(spendlyColors.cardSurface)
                                .drawBehind {
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                glowColor.copy(alpha = if (spendlyColors.isDark) 0.18f else 0.10f),
                                                Color.Transparent
                                            ),
                                            center = Offset(size.width * 0.88f, size.height * 0.12f),
                                            radius = size.width * 0.75f
                                        ),
                                        radius = size.width * 0.75f,
                                        center = Offset(size.width * 0.88f, size.height * 0.12f)
                                    )
                                }
                                .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(26.dp))
                                .padding(if (isCompactWidth) 16.dp else 20.dp)
                                .testTag("hero_balance_card")
                        ) {
                            val savingsPositive = uiState.monthlySavings >= 0.0
                            val savingsColor = if (savingsPositive) spendlyColors.income else spendlyColors.expense
                            val savingsBg = if (savingsPositive) spendlyColors.incomeContainer else spendlyColors.expenseContainer

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "TOTAL BALANCE",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = spendlyColors.mutedText
                                )

                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(savingsBg)
                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.TrendingUp,
                                        contentDescription = "Monthly savings",
                                        tint = savingsColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "${DateUtils.formatShortMonth(uiState.selectedMonthKey)} Savings " +
                                            CurrencyFormatter.formatCompact(uiState.monthlySavings, symbol, indian),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = MonoFontFamily,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = savingsColor,
                                        maxLines = 1
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = CurrencyFormatter.formatExact(uiState.totalBalance, symbol, indian),
                                style = if (isCompactWidth) {
                                    MaterialTheme.typography.displayMedium.copy(fontFamily = MonoFontFamily)
                                } else {
                                    MaterialTheme.typography.displayLarge.copy(fontFamily = MonoFontFamily)
                                },
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.testTag("total_balance_value")
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            // Total Income & Total Expenses split metrics (month-aware subtitle)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                MetricTile(
                                    label = "Total Income",
                                    value = CurrencyFormatter.format(uiState.totalIncome, symbol, indian),
                                    monthCaption = "${DateUtils.formatShortMonth(uiState.selectedMonthKey)}: ${
                                        CurrencyFormatter.formatCompact(uiState.monthlyIncome, symbol, indian)
                                    }",
                                    icon = Icons.Rounded.ArrowDownward,
                                    accent = spendlyColors.income,
                                    badgeBg = spendlyColors.incomeContainer,
                                    isCompact = isCompactWidth,
                                    modifier = Modifier.weight(1f)
                                )
                                MetricTile(
                                    label = "Total Expenses",
                                    value = CurrencyFormatter.format(uiState.totalExpenses, symbol, indian),
                                    monthCaption = "${DateUtils.formatShortMonth(uiState.selectedMonthKey)}: ${
                                        CurrencyFormatter.formatCompact(uiState.monthlyExpenses, symbol, indian)
                                    }",
                                    icon = Icons.Rounded.ArrowUpward,
                                    accent = spendlyColors.expense,
                                    badgeBg = spendlyColors.expenseContainer,
                                    isCompact = isCompactWidth,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Quick Add Expense & Quick Add Income Buttons
                item(key = "quick_actions") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        QuickActionButton(
                            label = "Add Expense",
                            icon = Icons.Rounded.Remove,
                            containerColor = spendlyColors.expenseContainer,
                            contentColor = spendlyColors.expense,
                            borderColor = spendlyColors.expense.copy(alpha = 0.45f),
                            onClick = { onQuickAdd(TransactionType.EXPENSE) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_add_expense_button")
                        )
                        QuickActionButton(
                            label = "Add Income",
                            icon = Icons.Rounded.Add,
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            borderColor = MaterialTheme.colorScheme.primary,
                            onClick = { onQuickAdd(TransactionType.INCOME) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_add_income_button")
                        )
                    }
                }

                // Monthly Budget Progress
                item(key = "monthly_budget") {
                    SectionHeader(
                        title = "${DateUtils.formatShortMonth(uiState.selectedMonthKey)} Budget",
                        actionLabel = if (uiState.overallMonthlyBudget == null) "Set Budget" else "Manage",
                        onActionClick = onOpenBudgets
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    val overallBudget = uiState.overallMonthlyBudget
                    if (overallBudget != null) {
                        BudgetProgressCard(
                            item = overallBudget,
                            currencySymbol = symbol,
                            indianNumbering = indian,
                            onClick = onOpenBudgets
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 72.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(spendlyColors.cardSurface)
                                .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(20.dp))
                                .clickable(onClick = onOpenBudgets)
                                .padding(16.dp)
                                .testTag("setup_monthly_budget_card"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AccountBalanceWallet,
                                    contentDescription = "Set monthly budget",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Set a ${DateUtils.formatShortMonth(uiState.selectedMonthKey)} spending limit",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Track remaining budget, percentage used & alerts",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = spendlyColors.mutedText
                                )
                            }
                        }
                    }
                }

                // Expense vs Income Chart
                item(key = "income_vs_expense_chart") {
                    SectionHeader(
                        title = "Expense vs Income",
                        actionLabel = "Analytics",
                        onActionClick = onOpenAnalytics
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(spendlyColors.cardSurface)
                            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(22.dp))
                            .padding(16.dp)
                    ) {
                        IncomeVsExpenseChart(
                            series = uiState.incomeVsExpenseSeries,
                            currencySymbol = symbol,
                            indianNumbering = indian
                        )
                    }
                }

                // Recent Transactions
                item(key = "recent_header") {
                    SectionHeader(
                        title = "Recent Transactions",
                        actionLabel = if (uiState.allTransactions.isNotEmpty()) "See All" else null,
                        onActionClick = onOpenTransactions
                    )
                }

                if (uiState.recentTransactions.isEmpty()) {
                    item(key = "empty_recent") {
                        EmptyStateCard(
                            icon = Icons.Rounded.ReceiptLong,
                            title = "No transactions yet",
                            subtitle = "Record your first expense or income — everything stays 100% private and offline on your device.",
                            actionLabel = "Record Expense",
                            onActionClick = { onQuickAdd(TransactionType.EXPENSE) }
                        )
                    }
                } else {
                    items(
                        items = uiState.recentTransactions,
                        key = { "recent_${it.id}" }
                    ) { tx ->
                        TransactionRowCard(
                            transaction = tx,
                            currencySymbol = symbol,
                            indianNumbering = indian,
                            onClick = { onEditTransaction(tx) }
                        )
                    }
                }
            }

            // Dismiss scrim when Quick-Add Floating Speed-Dial is expanded
            if (isQuickFabExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { isQuickFabExpanded = false }
                )
            }

            // Floating Quick-Add Speed-Dial Button (Expenses & Income) safely above docked banner ad
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AnimatedVisibility(
                    visible = isQuickFabExpanded,
                    enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom),
                    exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom)
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FloatingQuickActionPill(
                            label = "Add Income",
                            icon = Icons.Rounded.ArrowDownward,
                            accentColor = spendlyColors.income,
                            containerColor = spendlyColors.cardSurface,
                            onClick = {
                                isQuickFabExpanded = false
                                onQuickAdd(TransactionType.INCOME)
                            },
                            tag = "fab_quick_add_income"
                        )
                        FloatingQuickActionPill(
                            label = "Add Expense",
                            icon = Icons.Rounded.ArrowUpward,
                            accentColor = spendlyColors.expense,
                            containerColor = spendlyColors.cardSurface,
                            onClick = {
                                isQuickFabExpanded = false
                                onQuickAdd(TransactionType.EXPENSE)
                            },
                            tag = "fab_quick_add_expense"
                        )
                    }
                }

                FloatingActionButton(
                    onClick = { isQuickFabExpanded = !isQuickFabExpanded },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(18.dp),
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .size(56.dp)
                        .semantics {
                            contentDescription = if (isQuickFabExpanded) {
                                "Close quick add menu"
                            } else {
                                "Quick add expense or income"
                            }
                        }
                        .testTag("dashboard_quick_add_fab")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        modifier = Modifier
                            .size(26.dp)
                            .rotate(fabRotation)
                    )
                }
            }
        }

        // Dedicated non-overlapping Google AdMob Adaptive Banner docked cleanly above Bottom Navigation
        AdaptiveBannerAd(
            adUnitId = settings.adConfig.activeDashboardBannerId,
            nonPersonalizedOnly = settings.nonPersonalizedAdsOnly,
            testTagName = "dashboard_adaptive_banner"
        )
    }
}

@Composable
private fun FloatingQuickActionPill(
    label: String,
    icon: ImageVector,
    accentColor: Color,
    containerColor: Color,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(containerColor)
            .border(1.dp, accentColor.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun MetricTile(
    label: String,
    value: String,
    monthCaption: String,
    icon: ImageVector,
    accent: Color,
    badgeBg: Color,
    isCompact: Boolean,
    modifier: Modifier = Modifier
) {
    val spendlyColors = LocalSpendlyColors.current
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(spendlyColors.elevatedCard)
            .semantics(mergeDescendants = true) {}
            .padding(horizontal = if (isCompact) 10.dp else 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(if (isCompact) 30.dp else 34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(badgeBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(if (isCompact) 16.dp else 18.dp)
            )
        }
        Spacer(modifier = Modifier.width(if (isCompact) 8.dp else 10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = spendlyColors.mutedText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontFamily = MonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isCompact) 12.sp else 13.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = monthCaption,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    borderColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(containerColor)
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
