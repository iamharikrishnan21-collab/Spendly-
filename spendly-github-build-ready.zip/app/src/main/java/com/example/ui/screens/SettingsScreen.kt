package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdConfig
import com.example.ads.AdMobManager
import com.example.data.local.AppSettings
import com.example.ui.theme.LocalSpendlyColors
import com.example.ui.theme.MonoFontFamily
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    transactionCount: Int,
    onBack: () -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onSelectCurrency: (String) -> Unit,
    onToggleIndianNumbering: (Boolean) -> Unit,
    onToggleBudgetWarnings: (Boolean) -> Unit,
    onSelectWarningThreshold: (Int) -> Unit,
    onExportCsv: () -> Unit,
    onBackupData: () -> Unit,
    onRestoreData: () -> Unit,
    onDeleteAllData: () -> Unit,
    onToggleNonPersonalizedAds: (Boolean) -> Unit,
    onOpenAdPrivacyOptions: () -> Unit,
    onUpdateAdConfig: (AdConfig) -> Unit,
    onOpenPrivacyPolicy: () -> Unit
) {
    BackHandler(onBack = onBack)

    val spendlyColors = LocalSpendlyColors.current
    val consentState by AdMobManager.consentState.collectAsStateWithLifecycle()

    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showAdConfigDialog by remember { mutableStateOf(false) }

    val currencies = listOf("₹" to "INR", "$" to "USD", "€" to "EUR", "£" to "GBP")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Appearance & Currency
                item(key = "appearance_section") {
                    SettingsSectionCard(title = "Appearance & Currency") {
                        SettingsSwitchRow(
                            icon = Icons.Rounded.DarkMode,
                            title = "Dark Mode",
                            subtitle = "Signature obsidian & emerald fintech interface",
                            checked = settings.isDarkMode,
                            onCheckedChange = onToggleDarkMode,
                            tag = "settings_dark_mode_switch"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Default Currency",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            currencies.forEach { (sym, code) ->
                                val isSel = settings.currencySymbol == sym
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSel) MaterialTheme.colorScheme.primaryContainer
                                            else spendlyColors.elevatedCard
                                        )
                                        .border(
                                            1.dp,
                                            if (isSel) MaterialTheme.colorScheme.primary else spendlyColors.subtleBorder,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { onSelectCurrency(sym) }
                                        .testTag("currency_option_$code"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$sym $code",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSel) MaterialTheme.colorScheme.primary else spendlyColors.mutedText
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val previewText = CurrencyFormatter.formatExact(
                            123456.75,
                            settings.currencySymbol,
                            settings.useIndianNumbering
                        )
                        SettingsSwitchRow(
                            icon = Icons.Rounded.Tune,
                            title = "Indian Numbering System",
                            subtitle = "Preview: $previewText",
                            checked = settings.useIndianNumbering,
                            onCheckedChange = onToggleIndianNumbering,
                            tag = "settings_indian_numbering_switch"
                        )
                    }
                }

                // Budget Warning Notifications
                item(key = "notifications_section") {
                    SettingsSectionCard(title = "Budget Alerts") {
                        SettingsSwitchRow(
                            icon = Icons.Rounded.NotificationsActive,
                            title = "Budget Warning Notifications",
                            subtitle = "Alert when spending reaches ${settings.warningThresholdPercent}% or exceeds limit",
                            checked = settings.budgetWarningsEnabled,
                            onCheckedChange = onToggleBudgetWarnings,
                            tag = "settings_budget_warnings_switch"
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Warning Threshold",
                            style = MaterialTheme.typography.labelMedium,
                            color = spendlyColors.mutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(70, 80, 90).forEach { pct ->
                                val isSel = settings.warningThresholdPercent == pct
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSel) MaterialTheme.colorScheme.primaryContainer
                                            else spendlyColors.elevatedCard
                                        )
                                        .border(
                                            1.dp,
                                            if (isSel) MaterialTheme.colorScheme.primary else spendlyColors.subtleBorder,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { onSelectWarningThreshold(pct) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$pct%",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontFamily = MonoFontFamily,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = if (isSel) MaterialTheme.colorScheme.primary else spendlyColors.mutedText
                                    )
                                }
                            }
                        }
                    }
                }

                // Offline Data Management (CSV, Backup, Restore, Delete All)
                item(key = "data_section") {
                    SettingsSectionCard(title = "Local Data & Export (100% Offline)") {
                        SettingsActionRow(
                            icon = Icons.Rounded.Download,
                            title = "Export Transactions to CSV",
                            subtitle = "Save $transactionCount transaction(s) as spreadsheet CSV",
                            onClick = onExportCsv,
                            tag = "settings_export_csv"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SettingsActionRow(
                            icon = Icons.Rounded.Backup,
                            title = "Backup Local Data",
                            subtitle = "Save complete offline JSON backup of transactions & budgets",
                            onClick = onBackupData,
                            tag = "settings_backup_data"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SettingsActionRow(
                            icon = Icons.Rounded.Restore,
                            title = "Restore Local Data",
                            subtitle = "Import transactions & budgets from a Spendly JSON backup",
                            onClick = onRestoreData,
                            tag = "settings_restore_data"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SettingsActionRow(
                            icon = Icons.Rounded.DeleteForever,
                            title = "Delete All Data",
                            subtitle = "Permanently wipe all local transactions and budgets",
                            accent = spendlyColors.expense,
                            onClick = { showDeleteAllDialog = true },
                            tag = "settings_delete_all_data"
                        )
                    }
                }

                // Google AdMob & Privacy Setup
                item(key = "admob_section") {
                    SettingsSectionCard(title = "AdMob & Ad Privacy") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(spendlyColors.elevatedCard)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (settings.adConfig.isProductionMode) "Production Ad Units" else "Google Test Ads Active",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Consent: ${consentState.statusLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = spendlyColors.mutedText
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        SettingsSwitchRow(
                            icon = Icons.Rounded.Shield,
                            title = "Non-Personalized Ads Only",
                            subtitle = "Request contextual ads without behavioral targeting (NPA)",
                            checked = settings.nonPersonalizedAdsOnly,
                            onCheckedChange = onToggleNonPersonalizedAds,
                            tag = "settings_npa_switch"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        SettingsActionRow(
                            icon = Icons.Rounded.Policy,
                            title = "Manage Ad Consent Preferences",
                            subtitle = "Update Google UMP privacy & consent choices",
                            onClick = onOpenAdPrivacyOptions,
                            tag = "settings_ump_consent"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        SettingsActionRow(
                            icon = Icons.Rounded.Tune,
                            title = "Ad Unit Configuration",
                            subtitle = "Configure Banner, Native & Rewarded unit IDs for production",
                            onClick = { showAdConfigDialog = true },
                            tag = "settings_ad_unit_config"
                        )
                    }
                }

                // Legal & About
                item(key = "legal_section") {
                    SettingsSectionCard(title = "Legal & About") {
                        SettingsActionRow(
                            icon = Icons.Rounded.Policy,
                            title = "Privacy Policy",
                            subtitle = "Offline SQLite privacy guarantee & AdMob disclosure",
                            onClick = onOpenPrivacyPolicy,
                            tag = "settings_privacy_policy"
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Spendly v1.0 • Offline-First Expense Manager • No Account Required",
                            style = MaterialTheme.typography.labelSmall,
                            color = spendlyColors.mutedText
                        )
                    }
                }

                item(key = "settings_bottom_spacer") { Spacer(modifier = Modifier.height(20.dp)) }
            }
        }
    }

    // Delete All Data Confirmation Dialog
    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            containerColor = spendlyColors.cardSurface,
            title = { Text("Delete All Local Data?") },
            text = {
                Text(
                    "This will permanently erase all $transactionCount transactions and all monthly/category budgets from your device. Consider creating a JSON backup first."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteAllData()
                        showDeleteAllDialog = false
                    },
                    modifier = Modifier.testTag("confirm_delete_all_button")
                ) {
                    Text("Delete Everything", color = spendlyColors.expense, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Configurable AdMob Unit IDs Dialog
    if (showAdConfigDialog) {
        var prodMode by remember(settings.adConfig) { mutableStateOf(settings.adConfig.isProductionMode) }
        var dashBanner by remember(settings.adConfig) { mutableStateOf(settings.adConfig.productionDashboardBannerUnitId) }
        var histBanner by remember(settings.adConfig) { mutableStateOf(settings.adConfig.productionHistoryBannerUnitId) }
        var nativeId by remember(settings.adConfig) { mutableStateOf(settings.adConfig.productionNativeUnitId) }
        var rewardedId by remember(settings.adConfig) { mutableStateOf(settings.adConfig.productionRewardedUnitId) }

        AlertDialog(
            onDismissRequest = { showAdConfigDialog = false },
            containerColor = spendlyColors.cardSurface,
            title = { Text("AdMob Unit Configuration") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Official Google test ad IDs are always used while Production Mode is OFF.",
                        style = MaterialTheme.typography.bodySmall,
                        color = spendlyColors.mutedText
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Use Production Ad IDs", style = MaterialTheme.typography.titleSmall)
                        Switch(checked = prodMode, onCheckedChange = { prodMode = it })
                    }
                    OutlinedTextField(
                        value = dashBanner,
                        onValueChange = { dashBanner = it },
                        label = { Text("Dashboard Banner ID") },
                        placeholder = { Text(AdConfig.TEST_BANNER_UNIT_ID) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = histBanner,
                        onValueChange = { histBanner = it },
                        label = { Text("History Banner ID") },
                        placeholder = { Text(AdConfig.TEST_BANNER_UNIT_ID) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = nativeId,
                        onValueChange = { nativeId = it },
                        label = { Text("Native Ad Unit ID") },
                        placeholder = { Text(AdConfig.TEST_NATIVE_UNIT_ID) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = rewardedId,
                        onValueChange = { rewardedId = it },
                        label = { Text("Rewarded Ad Unit ID") },
                        placeholder = { Text(AdConfig.TEST_REWARDED_UNIT_ID) },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateAdConfig(
                            AdConfig(
                                isProductionMode = prodMode,
                                productionDashboardBannerUnitId = dashBanner,
                                productionHistoryBannerUnitId = histBanner,
                                productionNativeUnitId = nativeId,
                                productionRewardedUnitId = rewardedId
                            )
                        )
                        showAdConfigDialog = false
                    }
                ) {
                    Text("Save Config", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdConfigDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    val spendlyColors = LocalSpendlyColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(spendlyColors.cardSurface)
            .border(1.dp, spendlyColors.subtleBorder, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    val spendlyColors = LocalSpendlyColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(spendlyColors.elevatedCard),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = spendlyColors.mutedText
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tag: String,
    accent: Color? = null
) {
    val spendlyColors = LocalSpendlyColors.current
    val tintColor = accent ?: MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(spendlyColors.elevatedCard.copy(alpha = 0.55f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(tintColor.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tintColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = accent ?: MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = spendlyColors.mutedText
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = spendlyColors.mutedText
        )
    }
}
