package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {

    private val monthKeyFormat get() = SimpleDateFormat("yyyy-MM", Locale.US)
    private val monthLabelFormat get() = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
    private val shortMonthFormat get() = SimpleDateFormat("MMM", Locale.getDefault())
    private val dayKeyFormat get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val fullDateFormat get() = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val shortDayFormat get() = SimpleDateFormat("dd MMM", Locale.getDefault())
    private val timeFormat get() = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val csvTimestampFormat get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val fileStampFormat get() = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US)

    fun currentMonthKey(): String = monthKeyFormat.format(Date())

    fun monthKeyFromMillis(millis: Long): String = monthKeyFormat.format(Date(millis))

    fun formatMonthLabel(monthKey: String): String {
        val date = runCatching { monthKeyFormat.parse(monthKey) }.getOrNull() ?: Date()
        return monthLabelFormat.format(date)
    }

    fun formatShortMonth(monthKey: String): String {
        val date = runCatching { monthKeyFormat.parse(monthKey) }.getOrNull() ?: Date()
        return shortMonthFormat.format(date)
    }

    fun shiftMonthKey(monthKey: String, deltaMonths: Int): String {
        val date = runCatching { monthKeyFormat.parse(monthKey) }.getOrNull() ?: Date()
        val cal = Calendar.getInstance().apply {
            time = date
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, deltaMonths)
        }
        return monthKeyFormat.format(cal.time)
    }

    fun lastNMonthKeys(count: Int, endMonthKey: String = currentMonthKey()): List<String> {
        return (-(count - 1)..0).map { offset -> shiftMonthKey(endMonthKey, offset) }
    }

    fun formatSectionDate(millis: Long): String {
        val target = Calendar.getInstance().apply { timeInMillis = millis }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }

        return when {
            isSameDay(target, today) -> "Today"
            isSameDay(target, yesterday) -> "Yesterday"
            else -> fullDateFormat.format(Date(millis))
        }
    }

    fun formatFullDate(millis: Long): String = fullDateFormat.format(Date(millis))

    fun formatShortDay(millis: Long): String = shortDayFormat.format(Date(millis))

    fun formatTime(millis: Long): String = timeFormat.format(Date(millis))

    fun formatCsvDate(millis: Long): String = csvTimestampFormat.format(Date(millis))

    fun fileTimestamp(): String = fileStampFormat.format(Date())

    fun dayKeyFromMillis(millis: Long): String = dayKeyFormat.format(Date(millis))

    fun startOfTodayMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun startOfWeekMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -6)
    }.timeInMillis

    fun startOfMonthMillis(monthKey: String = currentMonthKey()): Long {
        val date = runCatching { monthKeyFormat.parse(monthKey) }.getOrNull() ?: Date()
        return Calendar.getInstance().apply {
            time = date
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun endOfMonthMillis(monthKey: String = currentMonthKey()): Long {
        val date = runCatching { monthKeyFormat.parse(monthKey) }.getOrNull() ?: Date()
        return Calendar.getInstance().apply {
            time = date
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis
    }

    fun combineDateAndTime(dateMillis: Long, hourOfDay: Int, minute: Int): Long {
        val dateCal = Calendar.getInstance().apply { timeInMillis = dateMillis }
        return Calendar.getInstance().apply {
            set(Calendar.YEAR, dateCal.get(Calendar.YEAR))
            set(Calendar.MONTH, dateCal.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, dateCal.get(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, hourOfDay)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private fun isSameDay(a: Calendar, b: Calendar): Boolean {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    }
}
