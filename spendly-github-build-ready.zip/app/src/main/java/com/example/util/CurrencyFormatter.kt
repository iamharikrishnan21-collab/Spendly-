package com.example.util

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

object CurrencyFormatter {

    /**
     * Formats an amount using Indian numbering conventions (e.g. ₹1,23,456.50)
     * or international grouping (e.g. ₹123,456.50).
     */
    fun format(
        amount: Double,
        symbol: String = "₹",
        indianNumbering: Boolean = true,
        showDecimals: Boolean = true,
        showPlusSign: Boolean = false
    ): String {
        val safeAmount = if (amount.isFinite()) amount else 0.0
        val isNegative = safeAmount < -0.004
        val absValue = abs(safeAmount)

        val totalPaise = (absValue * 100.0).roundToLong()
        val integerPart = totalPaise / 100L
        val decimalPart = (totalPaise % 100L).toInt()

        val groupedInt = if (indianNumbering) {
            formatIndianGrouping(integerPart)
        } else {
            formatInternationalGrouping(integerPart)
        }

        val decimals = if (showDecimals) {
            if (decimalPart == 0 && absValue >= 1000.0) {
                ""
            } else if (decimalPart == 0) {
                ".00"
            } else {
                String.format(Locale.US, ".%02d", decimalPart)
            }
        } else {
            ""
        }

        val sign = when {
            isNegative -> "-"
            showPlusSign && totalPaise > 0 -> "+"
            else -> ""
        }
        return "$sign$symbol$groupedInt$decimals"
    }

    /**
     * Always includes two decimals for exact financial receipts and CSV reports.
     */
    fun formatExact(
        amount: Double,
        symbol: String = "₹",
        indianNumbering: Boolean = true,
        showPlusSign: Boolean = false
    ): String {
        val safeAmount = if (amount.isFinite()) amount else 0.0
        val isNegative = safeAmount < -0.004
        val absValue = abs(safeAmount)
        val totalPaise = (absValue * 100.0).roundToLong()
        val integerPart = totalPaise / 100L
        val decimalPart = (totalPaise % 100L).toInt()

        val groupedInt = if (indianNumbering) {
            formatIndianGrouping(integerPart)
        } else {
            formatInternationalGrouping(integerPart)
        }
        val sign = when {
            isNegative -> "-"
            showPlusSign && totalPaise > 0 -> "+"
            else -> ""
        }
        return "$sign$symbol$groupedInt.${String.format(Locale.US, "%02d", decimalPart)}"
    }

    /**
     * Compact chart axis / badge format using Indian Lakhs/Crores or K/M.
     */
    fun formatCompact(
        amount: Double,
        symbol: String = "₹",
        indianNumbering: Boolean = true
    ): String {
        val safeAmount = if (amount.isFinite()) amount else 0.0
        val sign = if (safeAmount < 0) "-" else ""
        val value = abs(safeAmount)

        return if (indianNumbering) {
            when {
                value >= 1_00_00_000 -> "$sign$symbol${trimTrailingZero(value / 1_00_00_000.0)}Cr"
                value >= 1_00_000 -> "$sign$symbol${trimTrailingZero(value / 1_00_000.0)}L"
                value >= 1_000 -> "$sign$symbol${trimTrailingZero(value / 1_000.0)}K"
                else -> "$sign$symbol${value.roundToLong()}"
            }
        } else {
            when {
                value >= 1_000_000_000 -> "$sign$symbol${trimTrailingZero(value / 1_000_000_000.0)}B"
                value >= 1_000_000 -> "$sign$symbol${trimTrailingZero(value / 1_000_000.0)}M"
                value >= 1_000 -> "$sign$symbol${trimTrailingZero(value / 1_000.0)}K"
                else -> "$sign$symbol${value.roundToLong()}"
            }
        }
    }

    private fun formatIndianGrouping(value: Long): String {
        val digits = value.toString()
        if (digits.length <= 3) return digits
        val lastThree = digits.takeLast(3)
        val remaining = digits.dropLast(3)
        val sb = StringBuilder()
        var index = remaining.length
        while (index > 2) {
            sb.insert(0, ",${remaining.substring(index - 2, index)}")
            index -= 2
        }
        sb.insert(0, remaining.substring(0, index))
        sb.append(",").append(lastThree)
        return sb.toString()
    }

    private fun formatInternationalGrouping(value: Long): String {
        val digits = value.toString()
        if (digits.length <= 3) return digits
        val sb = StringBuilder()
        var count = 0
        for (i in digits.length - 1 downTo 0) {
            if (count > 0 && count % 3 == 0) {
                sb.insert(0, ',')
            }
            sb.insert(0, digits[i])
            count++
        }
        return sb.toString()
    }

    private fun trimTrailingZero(value: Double): String {
        val formatted = String.format(Locale.US, "%.1f", value)
        return if (formatted.endsWith(".0")) formatted.dropLast(2) else formatted
    }
}
