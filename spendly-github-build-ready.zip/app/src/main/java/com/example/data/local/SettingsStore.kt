package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ads.AdConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.spendlyDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "spendly_settings"
)

data class AppSettings(
    val isDarkMode: Boolean = true,
    val currencySymbol: String = "₹",
    val useIndianNumbering: Boolean = true,
    val budgetWarningsEnabled: Boolean = true,
    val warningThresholdPercent: Int = 80,
    val adConfig: AdConfig = AdConfig(),
    val nonPersonalizedAdsOnly: Boolean = false
)

class SettingsStore(private val context: Context) {

    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
        val INDIAN_NUMBERING = booleanPreferencesKey("indian_numbering")
        val BUDGET_WARNINGS = booleanPreferencesKey("budget_warnings")
        val WARNING_THRESHOLD = intPreferencesKey("warning_threshold")
        val PRODUCTION_ADS = booleanPreferencesKey("production_ads")
        val DASHBOARD_BANNER_ID = stringPreferencesKey("dashboard_banner_id")
        val HISTORY_BANNER_ID = stringPreferencesKey("history_banner_id")
        val NATIVE_AD_ID = stringPreferencesKey("native_ad_id")
        val REWARDED_AD_ID = stringPreferencesKey("rewarded_ad_id")
        val NON_PERSONALIZED_ADS = booleanPreferencesKey("non_personalized_ads")
    }

    val settingsFlow: Flow<AppSettings> = context.spendlyDataStore.data.map { prefs ->
        AppSettings(
            isDarkMode = prefs[Keys.DARK_MODE] ?: true,
            currencySymbol = prefs[Keys.CURRENCY_SYMBOL] ?: "₹",
            useIndianNumbering = prefs[Keys.INDIAN_NUMBERING] ?: true,
            budgetWarningsEnabled = prefs[Keys.BUDGET_WARNINGS] ?: true,
            warningThresholdPercent = (prefs[Keys.WARNING_THRESHOLD] ?: 80).coerceIn(50, 95),
            adConfig = AdConfig(
                isProductionMode = prefs[Keys.PRODUCTION_ADS] ?: false,
                productionDashboardBannerUnitId = prefs[Keys.DASHBOARD_BANNER_ID] ?: "",
                productionHistoryBannerUnitId = prefs[Keys.HISTORY_BANNER_ID] ?: "",
                productionNativeUnitId = prefs[Keys.NATIVE_AD_ID] ?: "",
                productionRewardedUnitId = prefs[Keys.REWARDED_AD_ID] ?: ""
            ),
            nonPersonalizedAdsOnly = prefs[Keys.NON_PERSONALIZED_ADS] ?: false
        )
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.spendlyDataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setCurrencySymbol(symbol: String) {
        context.spendlyDataStore.edit { it[Keys.CURRENCY_SYMBOL] = symbol }
    }

    suspend fun setIndianNumbering(enabled: Boolean) {
        context.spendlyDataStore.edit { it[Keys.INDIAN_NUMBERING] = enabled }
    }

    suspend fun setBudgetWarningsEnabled(enabled: Boolean) {
        context.spendlyDataStore.edit { it[Keys.BUDGET_WARNINGS] = enabled }
    }

    suspend fun setWarningThresholdPercent(percent: Int) {
        context.spendlyDataStore.edit { it[Keys.WARNING_THRESHOLD] = percent.coerceIn(50, 95) }
    }

    suspend fun setNonPersonalizedAdsOnly(enabled: Boolean) {
        context.spendlyDataStore.edit { it[Keys.NON_PERSONALIZED_ADS] = enabled }
    }

    suspend fun updateAdConfig(config: AdConfig) {
        context.spendlyDataStore.edit { prefs ->
            prefs[Keys.PRODUCTION_ADS] = config.isProductionMode
            prefs[Keys.DASHBOARD_BANNER_ID] = config.productionDashboardBannerUnitId.trim()
            prefs[Keys.HISTORY_BANNER_ID] = config.productionHistoryBannerUnitId.trim()
            prefs[Keys.NATIVE_AD_ID] = config.productionNativeUnitId.trim()
            prefs[Keys.REWARDED_AD_ID] = config.productionRewardedUnitId.trim()
        }
    }
}
