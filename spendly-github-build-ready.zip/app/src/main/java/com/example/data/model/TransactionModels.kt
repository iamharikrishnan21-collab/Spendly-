package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TransactionType(val label: String) {
    EXPENSE("Expense"),
    INCOME("Income");

    companion object {
        fun fromName(name: String): TransactionType =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: EXPENSE
    }
}

enum class TransactionCategory(
    val displayName: String,
    val icon: ImageVector,
    val accentColor: Color,
    val preferredType: TransactionType
) {
    FOOD("Food", Icons.Rounded.Restaurant, Color(0xFFFF8A4C), TransactionType.EXPENSE),
    SHOPPING("Shopping", Icons.Rounded.ShoppingBag, Color(0xFFF472B6), TransactionType.EXPENSE),
    TRANSPORT("Transport", Icons.Rounded.DirectionsCar, Color(0xFF38BDF8), TransactionType.EXPENSE),
    BILLS("Bills", Icons.Rounded.ReceiptLong, Color(0xFFFFB547), TransactionType.EXPENSE),
    HEALTH("Health", Icons.Rounded.LocalHospital, Color(0xFFFF5C77), TransactionType.EXPENSE),
    EDUCATION("Education", Icons.Rounded.School, Color(0xFFA78BFA), TransactionType.EXPENSE),
    ENTERTAINMENT("Entertainment", Icons.Rounded.Movie, Color(0xFFE879F9), TransactionType.EXPENSE),
    TRAVEL("Travel", Icons.Rounded.Flight, Color(0xFF2DD4BF), TransactionType.EXPENSE),
    SALARY("Salary", Icons.Rounded.AccountBalance, Color(0xFF00D09C), TransactionType.INCOME),
    BUSINESS("Business", Icons.Rounded.BusinessCenter, Color(0xFF34D399), TransactionType.INCOME),
    OTHER("Other", Icons.Rounded.Category, Color(0xFF94A3B8), TransactionType.EXPENSE);

    companion object {
        const val OVERALL_BUDGET_KEY = "OVERALL"

        fun fromName(name: String): TransactionCategory =
            entries.firstOrNull {
                it.name.equals(name, ignoreCase = true) ||
                    it.displayName.equals(name, ignoreCase = true)
            } ?: OTHER

        fun expenseCategories(): List<TransactionCategory> =
            entries.filter { it != SALARY && it != BUSINESS }

        fun incomeCategories(): List<TransactionCategory> =
            listOf(SALARY, BUSINESS, OTHER)
    }
}

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["category"]),
        Index(value = ["type"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val amount: Double,
    val type: String, // TransactionType.name
    val category: String, // TransactionCategory.name
    val note: String,
    val timestamp: Long,
    val createdAt: Long = System.currentTimeMillis()
) {
    val transactionType: TransactionType
        get() = TransactionType.fromName(type)

    val transactionCategory: TransactionCategory
        get() = TransactionCategory.fromName(category)
}

@Entity(
    tableName = "budgets",
    indices = [
        Index(value = ["monthKey", "categoryName"], unique = true)
    ]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val monthKey: String, // Format: "yyyy-MM"
    val categoryName: String, // "OVERALL" or TransactionCategory.name
    val limitAmount: Double
) {
    val isOverall: Boolean
        get() = categoryName == TransactionCategory.OVERALL_BUDGET_KEY

    val category: TransactionCategory?
        get() = if (isOverall) null else TransactionCategory.fromName(categoryName)
}
