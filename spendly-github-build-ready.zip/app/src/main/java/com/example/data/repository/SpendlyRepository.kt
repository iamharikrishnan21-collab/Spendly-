package com.example.data.repository

import com.example.data.local.AppSettings
import com.example.data.local.BudgetDao
import com.example.data.local.SettingsStore
import com.example.data.local.TransactionDao
import com.example.data.model.BudgetEntity
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class RestoreResult(
    val transactionsRestored: Int,
    val budgetsRestored: Int
)

class SpendlyRepository(
    private val transactionDao: TransactionDao,
    private val budgetDao: BudgetDao,
    val settingsStore: SettingsStore
) {
    val transactionsFlow: Flow<List<TransactionEntity>> = transactionDao.observeAllTransactions()
    val budgetsFlow: Flow<List<BudgetEntity>> = budgetDao.observeAllBudgets()
    val settingsFlow: Flow<AppSettings> = settingsStore.settingsFlow

    suspend fun addTransaction(transaction: TransactionEntity): Long =
        transactionDao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        transactionDao.updateTransaction(transaction)

    suspend fun deleteTransaction(id: Long) =
        transactionDao.deleteTransactionById(id)

    suspend fun upsertBudget(monthKey: String, categoryName: String, limitAmount: Double) {
        val existing = budgetDao.getBudget(monthKey, categoryName)
        val entity = if (existing != null) {
            existing.copy(limitAmount = limitAmount)
        } else {
            BudgetEntity(
                monthKey = monthKey,
                categoryName = categoryName,
                limitAmount = limitAmount
            )
        }
        budgetDao.upsertBudget(entity)
    }

    suspend fun deleteBudget(monthKey: String, categoryName: String) {
        budgetDao.deleteBudget(monthKey, categoryName)
    }

    suspend fun deleteAllData() {
        transactionDao.deleteAllTransactions()
        budgetDao.deleteAllBudgets()
    }

    suspend fun generateTransactionsCsv(): String = withContext(Dispatchers.Default) {
        val transactions = transactionDao.getAllTransactionsOnce()
        buildString {
            appendLine("ID,DateTime,Type,Category,Amount,Note")
            transactions.forEach { tx ->
                val escapedNote = tx.note.replace("\"", "\"\"")
                appendLine(
                    "${tx.id},\"${DateUtils.formatCsvDate(tx.timestamp)}\"," +
                        "${tx.transactionType.label},${tx.transactionCategory.displayName}," +
                        "${tx.amount},\"$escapedNote\""
                )
            }
        }
    }

    /**
     * Premium detailed report unlocked via optional rewarded ad on Analytics screen.
     */
    suspend fun generateDetailedFinancialReport(
        symbol: String,
        indianNumbering: Boolean
    ): String = withContext(Dispatchers.Default) {
        val transactions = transactionDao.getAllTransactionsOnce()
        val budgets = budgetDao.getAllBudgetsOnce()
        val totalIncome = transactions
            .filter { it.transactionType == TransactionType.INCOME }
            .sumOf { it.amount }
        val totalExpense = transactions
            .filter { it.transactionType == TransactionType.EXPENSE }
            .sumOf { it.amount }
        val netBalance = totalIncome - totalExpense
        val savingsRate = if (totalIncome > 0) ((netBalance / totalIncome) * 100.0) else 0.0

        val categoryBreakdown = transactions
            .filter { it.transactionType == TransactionType.EXPENSE }
            .groupBy { it.transactionCategory }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
            .entries
            .sortedByDescending { it.value }

        buildString {
            appendLine("SPENDLY PREMIUM FINANCIAL REPORT")
            appendLine("Generated At,\"${DateUtils.formatCsvDate(System.currentTimeMillis())}\"")
            appendLine()
            appendLine("EXECUTIVE SUMMARY")
            appendLine("Metric,Value")
            appendLine("Total Income,\"${CurrencyFormatter.formatExact(totalIncome, symbol, indianNumbering)}\"")
            appendLine("Total Expenses,\"${CurrencyFormatter.formatExact(totalExpense, symbol, indianNumbering)}\"")
            appendLine("Net Balance,\"${CurrencyFormatter.formatExact(netBalance, symbol, indianNumbering)}\"")
            appendLine("Savings Rate,\"${String.format("%.1f%%", savingsRate)}\"")
            appendLine("Total Transactions,${transactions.size}")
            appendLine("Configured Budgets,${budgets.size}")
            appendLine()
            appendLine("CATEGORY EXPENSE BREAKDOWN")
            appendLine("Category,Total Spent,Share")
            categoryBreakdown.forEach { (category, amount) ->
                val pct = if (totalExpense > 0) (amount / totalExpense) * 100.0 else 0.0
                appendLine(
                    "${category.displayName}," +
                        "\"${CurrencyFormatter.formatExact(amount, symbol, indianNumbering)}\"," +
                        "\"${String.format("%.1f%%", pct)}\""
                )
            }
            appendLine()
            appendLine("ALL TRANSACTIONS")
            appendLine("ID,DateTime,Type,Category,Amount,Note")
            transactions.forEach { tx ->
                val escapedNote = tx.note.replace("\"", "\"\"")
                appendLine(
                    "${tx.id},\"${DateUtils.formatCsvDate(tx.timestamp)}\"," +
                        "${tx.transactionType.label},${tx.transactionCategory.displayName}," +
                        "${tx.amount},\"$escapedNote\""
                )
            }
        }
    }

    suspend fun generateLocalBackupJson(): String = withContext(Dispatchers.Default) {
        val transactions = transactionDao.getAllTransactionsOnce()
        val budgets = budgetDao.getAllBudgetsOnce()

        val root = JSONObject().apply {
            put("app", "Spendly")
            put("schemaVersion", 1)
            put("exportedAt", System.currentTimeMillis())
            put("transactions", JSONArray().apply {
                transactions.forEach { tx ->
                    put(
                        JSONObject().apply {
                            put("amount", tx.amount)
                            put("type", tx.type)
                            put("category", tx.category)
                            put("note", tx.note)
                            put("timestamp", tx.timestamp)
                            put("createdAt", tx.createdAt)
                        }
                    )
                }
            })
            put("budgets", JSONArray().apply {
                budgets.forEach { budget ->
                    put(
                        JSONObject().apply {
                            put("monthKey", budget.monthKey)
                            put("categoryName", budget.categoryName)
                            put("limitAmount", budget.limitAmount)
                        }
                    )
                }
            })
        }
        root.toString(2)
    }

    suspend fun restoreFromBackupJson(
        rawJson: String,
        replaceExisting: Boolean
    ): Result<RestoreResult> = withContext(Dispatchers.Default) {
        runCatching {
            val root = JSONObject(rawJson)
            if (root.optString("app") != "Spendly" && !root.has("transactions")) {
                throw IllegalArgumentException("This file is not a valid Spendly backup.")
            }

            val txArray = root.optJSONArray("transactions") ?: JSONArray()
            val parsedTransactions = mutableListOf<TransactionEntity>()
            for (i in 0 until txArray.length()) {
                val obj = txArray.getJSONObject(i)
                val amount = obj.optDouble("amount", -1.0)
                if (!amount.isFinite() || amount <= 0.0) continue
                val type = TransactionType.fromName(obj.optString("type", "EXPENSE")).name
                val category = TransactionCategory.fromName(obj.optString("category", "OTHER")).name
                val note = obj.optString("note", "").take(250)
                val timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                val createdAt = obj.optLong("createdAt", timestamp)
                parsedTransactions.add(
                    TransactionEntity(
                        amount = amount,
                        type = type,
                        category = category,
                        note = note,
                        timestamp = timestamp,
                        createdAt = createdAt
                    )
                )
            }

            val budgetArray = root.optJSONArray("budgets") ?: JSONArray()
            val parsedBudgets = mutableListOf<BudgetEntity>()
            for (i in 0 until budgetArray.length()) {
                val obj = budgetArray.getJSONObject(i)
                val monthKey = obj.optString("monthKey", "").trim()
                val categoryName = obj.optString("categoryName", "").trim()
                val limitAmount = obj.optDouble("limitAmount", -1.0)
                if (monthKey.length != 7 || categoryName.isEmpty() || !limitAmount.isFinite() || limitAmount <= 0.0) {
                    continue
                }
                parsedBudgets.add(
                    BudgetEntity(
                        monthKey = monthKey,
                        categoryName = categoryName,
                        limitAmount = limitAmount
                    )
                )
            }

            if (replaceExisting) {
                transactionDao.deleteAllTransactions()
                budgetDao.deleteAllBudgets()
            }
            if (parsedTransactions.isNotEmpty()) {
                transactionDao.insertAll(parsedTransactions)
            }
            parsedBudgets.forEach { budget ->
                upsertBudget(budget.monthKey, budget.categoryName, budget.limitAmount)
            }

            RestoreResult(
                transactionsRestored = parsedTransactions.size,
                budgetsRestored = parsedBudgets.size
            )
        }
    }
}
