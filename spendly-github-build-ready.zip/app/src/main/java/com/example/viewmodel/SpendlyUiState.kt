package com.example.viewmodel

import com.example.data.local.AppSettings
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.DateUtils

enum class DateRangeFilter(val label: String) {
    ALL("All Time"),
    TODAY("Today"),
    THIS_WEEK("7 Days"),
    THIS_MONTH("This Month"),
    CUSTOM("Custom")
}

data class TransactionFilters(
    val searchQuery: String = "",
    val typeFilter: TransactionType? = null,
    val categoryFilter: TransactionCategory? = null,
    val dateRange: DateRangeFilter = DateRangeFilter.ALL,
    val customStartMillis: Long? = null,
    val customEndMillis: Long? = null
) {
    val hasActiveFilters: Boolean
        get() = searchQuery.isNotBlank() ||
            typeFilter != null ||
            categoryFilter != null ||
            dateRange != DateRangeFilter.ALL
}

data class BudgetStatusItem(
    val categoryName: String,
    val displayTitle: String,
    val category: TransactionCategory?,
    val limitAmount: Double,
    val spentAmount: Double,
    val warningThresholdPercent: Int
) {
    val remainingAmount: Double get() = limitAmount - spentAmount
    val progressRatio: Float get() = if (limitAmount > 0.0) (spentAmount / limitAmount).toFloat() else 0f
    val clampedProgress: Float get() = progressRatio.coerceIn(0f, 1f)
    val percentUsed: Int get() = (progressRatio * 100f).toInt()
    val isExceeded: Boolean get() = limitAmount > 0.0 && spentAmount > limitAmount
    val isWarning: Boolean get() = limitAmount > 0.0 && !isExceeded && percentUsed >= warningThresholdPercent
}

data class ChartBarPoint(
    val label: String,
    val fullLabel: String,
    val value: Double
)

data class MonthlyComparisonPoint(
    val monthKey: String,
    val shortLabel: String,
    val income: Double,
    val expense: Double
) {
    val savings: Double get() = income - expense
}

data class CategorySpendSlice(
    val category: TransactionCategory,
    val amount: Double,
    val percentage: Float
)

data class SpendlyUiState(
    val settings: AppSettings = AppSettings(),
    val selectedMonthKey: String = DateUtils.currentMonthKey(),
    val allTransactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val filters: TransactionFilters = TransactionFilters(),
    // Dashboard financial metrics
    val totalBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val monthlyIncome: Double = 0.0,
    val monthlyExpenses: Double = 0.0,
    val monthlySavings: Double = 0.0,
    val recentTransactions: List<TransactionEntity> = emptyList(),
    // Budgets
    val overallMonthlyBudget: BudgetStatusItem? = null,
    val categoryBudgets: List<BudgetStatusItem> = emptyList(),
    val activeBudgetWarnings: List<BudgetStatusItem> = emptyList(),
    // Analytics datasets
    val dailyExpenses: List<ChartBarPoint> = emptyList(),
    val weeklyExpenses: List<ChartBarPoint> = emptyList(),
    val monthlyExpensesSeries: List<ChartBarPoint> = emptyList(),
    val categoryBreakdown: List<CategorySpendSlice> = emptyList(),
    val incomeVsExpenseSeries: List<MonthlyComparisonPoint> = emptyList(),
    val savingsTrendSeries: List<ChartBarPoint> = emptyList()
)
