package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdConfig
import com.example.data.local.AppSettings
import com.example.data.local.SettingsStore
import com.example.data.local.SpendlyDatabase
import com.example.data.model.BudgetEntity
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.RestoreResult
import com.example.data.repository.SpendlyRepository
import com.example.util.BudgetNotificationHelper
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class SpendlyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SpendlyDatabase.getInstance(application)
    private val settingsStore = SettingsStore(application)
    private val repository = SpendlyRepository(
        transactionDao = database.transactionDao(),
        budgetDao = database.budgetDao(),
        settingsStore = settingsStore
    )

    private val _selectedMonthKey = MutableStateFlow(DateUtils.currentMonthKey())
    private val _filters = MutableStateFlow(TransactionFilters())

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    val uiState: StateFlow<SpendlyUiState> = combine(
        repository.transactionsFlow,
        repository.budgetsFlow,
        repository.settingsFlow,
        _selectedMonthKey,
        _filters
    ) { transactions, budgets, settings, monthKey, filters ->
        computeUiState(transactions, budgets, settings, monthKey, filters)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SpendlyUiState()
    )

    // --- Month Navigation ---

    fun shiftSelectedMonth(delta: Int) {
        _selectedMonthKey.value = DateUtils.shiftMonthKey(_selectedMonthKey.value, delta)
    }

    fun resetToCurrentMonth() {
        _selectedMonthKey.value = DateUtils.currentMonthKey()
    }

    // --- Transaction Filters ---

    fun updateSearchQuery(query: String) {
        _filters.value = _filters.value.copy(searchQuery = query)
    }

    fun updateTypeFilter(type: TransactionType?) {
        _filters.value = _filters.value.copy(typeFilter = type)
    }

    fun updateCategoryFilter(category: TransactionCategory?) {
        _filters.value = _filters.value.copy(categoryFilter = category)
    }

    fun updateDateRangeFilter(range: DateRangeFilter) {
        _filters.value = _filters.value.copy(dateRange = range)
    }

    fun setCustomDateRange(startMillis: Long, endMillis: Long) {
        _filters.value = _filters.value.copy(
            dateRange = DateRangeFilter.CUSTOM,
            customStartMillis = startMillis,
            customEndMillis = endMillis
        )
    }

    fun clearFilters() {
        _filters.value = TransactionFilters()
    }

    // --- Transaction CRUD ---

    fun saveTransaction(
        existingId: Long?,
        amount: Double,
        type: TransactionType,
        category: TransactionCategory,
        note: String,
        timestamp: Long
    ) {
        if (!amount.isFinite() || amount <= 0.0) {
            emitMessage("Please enter a valid positive amount.")
            return
        }
        viewModelScope.launch {
            val cleanNote = note.trim().take(250)
            if (existingId == null || existingId == 0L) {
                val entity = TransactionEntity(
                    amount = amount,
                    type = type.name,
                    category = category.name,
                    note = cleanNote,
                    timestamp = timestamp
                )
                repository.addTransaction(entity)
                emitMessage("${type.label} added")
            } else {
                val entity = TransactionEntity(
                    id = existingId,
                    amount = amount,
                    type = type.name,
                    category = category.name,
                    note = cleanNote,
                    timestamp = timestamp
                )
                repository.updateTransaction(entity)
                emitMessage("${type.label} updated")
            }

            if (type == TransactionType.EXPENSE) {
                checkAndTriggerBudgetWarnings(
                    monthKey = DateUtils.monthKeyFromMillis(timestamp),
                    category = category
                )
            }
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction.id)
            emitMessage("Transaction deleted")
        }
    }

    // --- Budget CRUD ---

    fun saveBudget(
        monthKey: String,
        categoryName: String,
        limitAmount: Double
    ) {
        if (!limitAmount.isFinite() || limitAmount <= 0.0) {
            emitMessage("Budget amount must be greater than zero.")
            return
        }
        viewModelScope.launch {
            repository.upsertBudget(monthKey, categoryName, limitAmount)
            val label = if (categoryName == TransactionCategory.OVERALL_BUDGET_KEY) {
                "Monthly budget"
            } else {
                "${TransactionCategory.fromName(categoryName).displayName} budget"
            }
            emitMessage("$label saved")
        }
    }

    fun removeBudget(monthKey: String, categoryName: String) {
        viewModelScope.launch {
            repository.deleteBudget(monthKey, categoryName)
            emitMessage("Budget removed")
        }
    }

    // --- Settings ---

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { repository.settingsStore.setDarkMode(enabled) }
    }

    fun setCurrencySymbol(symbol: String) {
        viewModelScope.launch { repository.settingsStore.setCurrencySymbol(symbol) }
    }

    fun setIndianNumbering(enabled: Boolean) {
        viewModelScope.launch { repository.settingsStore.setIndianNumbering(enabled) }
    }

    fun setBudgetWarningsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.settingsStore.setBudgetWarningsEnabled(enabled) }
    }

    fun setWarningThresholdPercent(percent: Int) {
        viewModelScope.launch { repository.settingsStore.setWarningThresholdPercent(percent) }
    }

    fun setNonPersonalizedAdsOnly(enabled: Boolean) {
        viewModelScope.launch { repository.settingsStore.setNonPersonalizedAdsOnly(enabled) }
    }

    fun updateAdConfig(config: AdConfig) {
        viewModelScope.launch {
            repository.settingsStore.updateAdConfig(config)
            emitMessage(
                if (config.isProductionMode) "Production AdMob config saved"
                else "Using official Google Test Ad IDs"
            )
        }
    }

    // --- Export / Backup / Restore / Delete All ---

    suspend fun buildCsvExport(): String = repository.generateTransactionsCsv()

    suspend fun buildPremiumReportExport(): String {
        val settings = uiState.value.settings
        return repository.generateDetailedFinancialReport(
            symbol = settings.currencySymbol,
            indianNumbering = settings.useIndianNumbering
        )
    }

    suspend fun buildBackupJson(): String = repository.generateLocalBackupJson()

    fun restoreBackup(rawJson: String, replaceExisting: Boolean) {
        viewModelScope.launch {
            val result: Result<RestoreResult> = repository.restoreFromBackupJson(rawJson, replaceExisting)
            result.onSuccess { restored ->
                emitMessage(
                    "Restored ${restored.transactionsRestored} transactions and ${restored.budgetsRestored} budgets"
                )
            }.onFailure { err ->
                emitMessage(err.message ?: "Could not restore backup file.")
            }
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            repository.deleteAllData()
            clearFilters()
            emitMessage("All local transactions and budgets deleted")
        }
    }

    fun emitMessage(message: String) {
        _snackbarMessages.tryEmit(message)
    }

    // --- Budget Warning Notifications ---

    private fun checkAndTriggerBudgetWarnings(
        monthKey: String,
        category: TransactionCategory
    ) {
        val current = uiState.value
        val settings = current.settings
        if (!settings.budgetWarningsEnabled) return

        val transactionsInMonth = current.allTransactions.filter {
            it.transactionType == TransactionType.EXPENSE &&
                DateUtils.monthKeyFromMillis(it.timestamp) == monthKey
        }
        val totalMonthExpense = transactionsInMonth.sumOf { it.amount }
        val categoryMonthExpense = transactionsInMonth
            .filter { it.transactionCategory == category }
            .sumOf { it.amount }

        val overallBudget = current.overallMonthlyBudget
        if (overallBudget != null && monthKey == current.selectedMonthKey && overallBudget.limitAmount > 0) {
            val pct = ((totalMonthExpense / overallBudget.limitAmount) * 100.0).toInt()
            if (pct >= settings.warningThresholdPercent) {
                val formattedSpent = CurrencyFormatter.format(
                    totalMonthExpense,
                    settings.currencySymbol,
                    settings.useIndianNumbering
                )
                val formattedLimit = CurrencyFormatter.format(
                    overallBudget.limitAmount,
                    settings.currencySymbol,
                    settings.useIndianNumbering
                )
                val title = if (pct >= 100) "Monthly Budget Exceeded" else "Monthly Budget Warning ($pct%)"
                val body = "You have spent $formattedSpent of your $formattedLimit monthly budget."
                BudgetNotificationHelper.showBudgetWarning(
                    context = getApplication(),
                    title = title,
                    message = body,
                    notificationId = 1001
                )
            }
        }

        val catBudget = current.categoryBudgets.firstOrNull { it.category == category }
        if (catBudget != null && monthKey == current.selectedMonthKey && catBudget.limitAmount > 0) {
            val pct = ((categoryMonthExpense / catBudget.limitAmount) * 100.0).toInt()
            if (pct >= settings.warningThresholdPercent) {
                val formattedSpent = CurrencyFormatter.format(
                    categoryMonthExpense,
                    settings.currencySymbol,
                    settings.useIndianNumbering
                )
                val formattedLimit = CurrencyFormatter.format(
                    catBudget.limitAmount,
                    settings.currencySymbol,
                    settings.useIndianNumbering
                )
                val title = if (pct >= 100) {
                    "${category.displayName} Budget Exceeded"
                } else {
                    "${category.displayName} Budget at $pct%"
                }
                val body = "Spent $formattedSpent of $formattedLimit in ${category.displayName}."
                BudgetNotificationHelper.showBudgetWarning(
                    context = getApplication(),
                    title = title,
                    message = body,
                    notificationId = 2000 + category.ordinal
                )
            }
        }
    }

    // --- Reactive State Aggregation ---

    private fun computeUiState(
        transactions: List<TransactionEntity>,
        budgets: List<BudgetEntity>,
        settings: AppSettings,
        monthKey: String,
        filters: TransactionFilters
    ): SpendlyUiState {
        val totalIncome = transactions
            .filter { it.transactionType == TransactionType.INCOME }
            .sumOf { it.amount }
        val totalExpenses = transactions
            .filter { it.transactionType == TransactionType.EXPENSE }
            .sumOf { it.amount }
        val totalBalance = totalIncome - totalExpenses

        val monthTransactions = transactions.filter { DateUtils.monthKeyFromMillis(it.timestamp) == monthKey }
        val monthlyIncome = monthTransactions
            .filter { it.transactionType == TransactionType.INCOME }
            .sumOf { it.amount }
        val monthlyExpenses = monthTransactions
            .filter { it.transactionType == TransactionType.EXPENSE }
            .sumOf { it.amount }
        val monthlySavings = monthlyIncome - monthlyExpenses

        val filtered = applyFilters(transactions, filters)

        // Budgets for selected month
        val monthBudgets = budgets.filter { it.monthKey == monthKey }
        val overallEntity = monthBudgets.firstOrNull { it.isOverall }
        val overallBudgetStatus = overallEntity?.let {
            BudgetStatusItem(
                categoryName = TransactionCategory.OVERALL_BUDGET_KEY,
                displayTitle = "Monthly Budget",
                category = null,
                limitAmount = it.limitAmount,
                spentAmount = monthlyExpenses,
                warningThresholdPercent = settings.warningThresholdPercent
            )
        }

        val expenseByCategoryInMonth = monthTransactions
            .filter { it.transactionType == TransactionType.EXPENSE }
            .groupBy { it.transactionCategory }
            .mapValues { (_, list) -> list.sumOf { it.amount } }

        val categoryBudgetStatuses = monthBudgets
            .filter { !it.isOverall }
            .mapNotNull { entity ->
                val cat = entity.category ?: return@mapNotNull null
                BudgetStatusItem(
                    categoryName = cat.name,
                    displayTitle = cat.displayName,
                    category = cat,
                    limitAmount = entity.limitAmount,
                    spentAmount = expenseByCategoryInMonth[cat] ?: 0.0,
                    warningThresholdPercent = settings.warningThresholdPercent
                )
            }
            .sortedByDescending { it.progressRatio }

        val warnings = buildList {
            if (overallBudgetStatus != null && (overallBudgetStatus.isWarning || overallBudgetStatus.isExceeded)) {
                add(overallBudgetStatus)
            }
            addAll(categoryBudgetStatuses.filter { it.isWarning || it.isExceeded })
        }

        // Analytics: Daily Expenses (last 14 days)
        val dailyExpenses = computeDailyExpenses(transactions, days = 14)

        // Analytics: Weekly Expenses (last 8 weeks)
        val weeklyExpenses = computeWeeklyExpenses(transactions, weeks = 8)

        // Analytics: Last 6 months Income vs Expense, Monthly Expenses, and Savings Trends
        val last6Months = DateUtils.lastNMonthKeys(count = 6, endMonthKey = monthKey)
        val monthlyComparison = last6Months.map { key ->
            val txs = transactions.filter { DateUtils.monthKeyFromMillis(it.timestamp) == key }
            val inc = txs.filter { it.transactionType == TransactionType.INCOME }.sumOf { it.amount }
            val exp = txs.filter { it.transactionType == TransactionType.EXPENSE }.sumOf { it.amount }
            MonthlyComparisonPoint(
                monthKey = key,
                shortLabel = DateUtils.formatShortMonth(key),
                income = inc,
                expense = exp
            )
        }

        val monthlyExpenseSeries = monthlyComparison.map {
            ChartBarPoint(
                label = it.shortLabel,
                fullLabel = DateUtils.formatMonthLabel(it.monthKey),
                value = it.expense
            )
        }

        val savingsTrendSeries = monthlyComparison.map {
            ChartBarPoint(
                label = it.shortLabel,
                fullLabel = DateUtils.formatMonthLabel(it.monthKey),
                value = it.savings
            )
        }

        // Category-wise spending for selected month (fallback to all-time if month is empty but all-time has expenses)
        val categorySourceMap = if (expenseByCategoryInMonth.isNotEmpty()) {
            expenseByCategoryInMonth
        } else {
            transactions
                .filter { it.transactionType == TransactionType.EXPENSE }
                .groupBy { it.transactionCategory }
                .mapValues { (_, list) -> list.sumOf { it.amount } }
        }
        val totalCategorySpend = categorySourceMap.values.sum()
        val categorySlices = categorySourceMap.entries
            .sortedByDescending { it.value }
            .map { (cat, amt) ->
                CategorySpendSlice(
                    category = cat,
                    amount = amt,
                    percentage = if (totalCategorySpend > 0) (amt / totalCategorySpend * 100.0).toFloat() else 0f
                )
            }

        return SpendlyUiState(
            settings = settings,
            selectedMonthKey = monthKey,
            allTransactions = transactions,
            filteredTransactions = filtered,
            filters = filters,
            totalBalance = totalBalance,
            totalIncome = totalIncome,
            totalExpenses = totalExpenses,
            monthlyIncome = monthlyIncome,
            monthlyExpenses = monthlyExpenses,
            monthlySavings = monthlySavings,
            recentTransactions = transactions.take(5),
            overallMonthlyBudget = overallBudgetStatus,
            categoryBudgets = categoryBudgetStatuses,
            activeBudgetWarnings = warnings,
            dailyExpenses = dailyExpenses,
            weeklyExpenses = weeklyExpenses,
            monthlyExpensesSeries = monthlyExpenseSeries,
            categoryBreakdown = categorySlices,
            incomeVsExpenseSeries = monthlyComparison,
            savingsTrendSeries = savingsTrendSeries
        )
    }

    private fun applyFilters(
        transactions: List<TransactionEntity>,
        filters: TransactionFilters
    ): List<TransactionEntity> {
        val query = filters.searchQuery.trim().lowercase()
        val todayStart = DateUtils.startOfTodayMillis()
        val weekStart = DateUtils.startOfWeekMillis()
        val monthStart = DateUtils.startOfMonthMillis()
        val monthEnd = DateUtils.endOfMonthMillis()

        return transactions.filter { tx ->
            val matchesType = filters.typeFilter == null || tx.transactionType == filters.typeFilter
            val matchesCategory = filters.categoryFilter == null || tx.transactionCategory == filters.categoryFilter
            val matchesQuery = query.isEmpty() ||
                tx.note.lowercase().contains(query) ||
                tx.transactionCategory.displayName.lowercase().contains(query) ||
                tx.amount.toString().contains(query)
            val matchesDate = when (filters.dateRange) {
                DateRangeFilter.ALL -> true
                DateRangeFilter.TODAY -> tx.timestamp >= todayStart
                DateRangeFilter.THIS_WEEK -> tx.timestamp >= weekStart
                DateRangeFilter.THIS_MONTH -> tx.timestamp in monthStart..monthEnd
                DateRangeFilter.CUSTOM -> {
                    val start = filters.customStartMillis ?: 0L
                    val end = filters.customEndMillis ?: Long.MAX_VALUE
                    tx.timestamp in start..end
                }
            }
            matchesType && matchesCategory && matchesQuery && matchesDate
        }
    }

    private fun computeDailyExpenses(
        transactions: List<TransactionEntity>,
        days: Int
    ): List<ChartBarPoint> {
        val expenses = transactions.filter { it.transactionType == TransactionType.EXPENSE }
        val byDayKey = expenses.groupBy { DateUtils.dayKeyFromMillis(it.timestamp) }
            .mapValues { (_, list) -> list.sumOf { it.amount } }

        val cal = Calendar.getInstance()
        return (-(days - 1)..0).map { offset ->
            val dayCal = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
            val millis = dayCal.timeInMillis
            val key = DateUtils.dayKeyFromMillis(millis)
            ChartBarPoint(
                label = dayCal.get(Calendar.DAY_OF_MONTH).toString(),
                fullLabel = DateUtils.formatShortDay(millis),
                value = byDayKey[key] ?: 0.0
            )
        }
    }

    private fun computeWeeklyExpenses(
        transactions: List<TransactionEntity>,
        weeks: Int
    ): List<ChartBarPoint> {
        val expenses = transactions.filter { it.transactionType == TransactionType.EXPENSE }
        val nowEnd = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis
        val weekMillis = 7L * 24L * 60L * 60L * 1000L

        return (weeks - 1 downTo 0).map { weeksAgo ->
            val end = nowEnd - weeksAgo * weekMillis
            val start = end - weekMillis + 1L
            val sum = expenses.filter { it.timestamp in start..end }.sumOf { it.amount }
            val label = if (weeksAgo == 0) "This Wk" else "W-${weeksAgo}"
            val full = "${DateUtils.formatShortDay(start)} – ${DateUtils.formatShortDay(end)}"
            ChartBarPoint(label = label, fullLabel = full, value = sum)
        }
    }
}
