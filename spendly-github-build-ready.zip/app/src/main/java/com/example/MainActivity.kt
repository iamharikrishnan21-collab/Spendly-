package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdMobManager
import com.example.ui.SpendlyApp
import com.example.ui.theme.SpendlyTheme
import com.example.util.BudgetNotificationHelper
import com.example.viewmodel.SpendlyViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SpendlyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Instant edge-to-edge dark fintech launch style
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        // Prepare local budget alerts notification channel
        BudgetNotificationHelper.ensureChannel(this)

        // Gather Google UMP consent & initialize AdMob asynchronously (offline-safe, zero launch blocking)
        AdMobManager.gatherConsentAndInitialize(this)

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val isDark = uiState.settings.isDarkMode

            LaunchedEffect(isDark) {
                if (isDark) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
                        navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
                    )
                } else {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                        navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    )
                }
            }

            SpendlyTheme(darkTheme = isDark) {
                SpendlyApp(viewModel = viewModel)
            }
        }
    }
}
