package com.example.ads

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.LocalSpendlyColors
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import androidx.compose.material3.MaterialTheme

/**
 * Policy-compliant Anchored Adaptive Banner Ad.
 * Never overlays navigation or buttons, collapses smoothly when offline or failed to load.
 */
@Composable
fun AdaptiveBannerAd(
    adUnitId: String,
    nonPersonalizedOnly: Boolean,
    modifier: Modifier = Modifier,
    testTagName: String = "adaptive_banner_ad"
) {
    val context = LocalContext.current
    val consentState by AdMobManager.consentState.collectAsStateWithLifecycle()
    val isOnline = remember(consentState.canRequestAds) { AdMobManager.isNetworkAvailable(context) }
    var isAdLoaded by remember(adUnitId) { mutableStateOf(false) }

    if (!isOnline || !consentState.canRequestAds) {
        return
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTagName),
        contentAlignment = Alignment.Center
    ) {
        val adWidthDp = maxWidth.value.toInt().coerceAtLeast(320)
        val adView = remember(adUnitId, adWidthDp, nonPersonalizedOnly) {
            runCatching {
                AdView(context).apply {
                    this.adUnitId = adUnitId
                    setAdSize(
                        AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                            context,
                            adWidthDp
                        )
                    )
                    adListener = object : AdListener() {
                        override fun onAdLoaded() {
                            isAdLoaded = true
                        }

                        override fun onAdFailedToLoad(error: LoadAdError) {
                            isAdLoaded = false
                        }
                    }
                    loadAd(AdMobManager.buildAdRequest(nonPersonalizedOnly))
                }
            }.getOrNull()
        }

        DisposableEffect(adView) {
            onDispose {
                runCatching { adView?.destroy() }
            }
        }

        if (adView != null) {
            val spendlyColors = LocalSpendlyColors.current
            AnimatedVisibility(
                visible = isAdLoaded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        androidx.compose.material3.HorizontalDivider(
                            color = spendlyColors.subtleBorder.copy(alpha = 0.65f),
                            thickness = 1.dp
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            AndroidView(
                                factory = { adView },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Policy-compliant Native Ad card styled to match Spendly's dark fintech card design.
 * Displayed cleanly between Transaction History rows (every 9 transactions).
 * Collapses cleanly when offline or if no ad fills.
 */
@Composable
fun NativeTransactionAdCard(
    adUnitId: String,
    nonPersonalizedOnly: Boolean,
    slotKey: Int,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val consentState by AdMobManager.consentState.collectAsStateWithLifecycle()
    val spendlyColors = LocalSpendlyColors.current
    val colorScheme = MaterialTheme.colorScheme
    val density = LocalDensity.current
    var loadedNativeAd by remember(adUnitId, slotKey) { mutableStateOf<NativeAd?>(null) }

    LaunchedEffect(adUnitId, slotKey, consentState.canRequestAds, nonPersonalizedOnly) {
        if (!consentState.canRequestAds || !AdMobManager.isNetworkAvailable(context)) return@LaunchedEffect
        runCatching {
            val loader = AdLoader.Builder(context, adUnitId)
                .forNativeAd { ad ->
                    loadedNativeAd?.destroy()
                    loadedNativeAd = ad
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        loadedNativeAd = null
                    }
                })
                .withNativeAdOptions(NativeAdOptions.Builder().build())
                .build()
            loader.loadAd(AdMobManager.buildAdRequest(nonPersonalizedOnly))
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { loadedNativeAd?.destroy() }
        }
    }

    val nativeAd = loadedNativeAd ?: return

    val cardBgArgb = spendlyColors.cardSurface.toArgb()
    val borderArgb = spendlyColors.subtleBorder.toArgb()
    val primaryTextArgb = colorScheme.onSurface.toArgb()
    val mutedTextArgb = spendlyColors.mutedText.toArgb()
    val emeraldArgb = colorScheme.primary.toArgb()
    val onEmeraldArgb = colorScheme.onPrimary.toArgb()
    val badgeBgArgb = spendlyColors.incomeContainer.toArgb()

    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("native_ad_slot_$slotKey"),
        factory = { ctx ->
            val dpToPx = { dp: Int -> (dp * density.density).toInt() }
            NativeAdView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                background = GradientDrawable().apply {
                    setColor(cardBgArgb)
                    cornerRadius = dpToPx(20).toFloat()
                    setStroke(dpToPx(1), borderArgb)
                }
                setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14))

                val rootCol = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                // Header row: Icon + Ad badge + Headline + Advertiser
                val headerRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                val iconView = ImageView(ctx).apply {
                    layoutParams = LinearLayout.LayoutParams(dpToPx(42), dpToPx(42)).apply {
                        marginEnd = dpToPx(12)
                    }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }

                val titleCol = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }

                val badgeRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val adBadge = TextView(ctx).apply {
                    text = "Ad"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(emeraldArgb)
                    background = GradientDrawable().apply {
                        setColor(badgeBgArgb)
                        cornerRadius = dpToPx(6).toFloat()
                    }
                    setPadding(dpToPx(6), dpToPx(2), dpToPx(6), dpToPx(2))
                }

                val advertiserTv = TextView(ctx).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setTextColor(mutedTextArgb)
                    setPadding(dpToPx(8), 0, 0, 0)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }

                val headlineTv = TextView(ctx).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(primaryTextArgb)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dpToPx(3), 0, 0)
                }

                badgeRow.addView(adBadge)
                badgeRow.addView(advertiserTv)
                titleCol.addView(badgeRow)
                titleCol.addView(headlineTv)

                headerRow.addView(iconView)
                headerRow.addView(titleCol)

                val bodyTv = TextView(ctx).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    setTextColor(mutedTextArgb)
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dpToPx(8), 0, dpToPx(10))
                }

                val ctaBtn = Button(ctx).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(onEmeraldArgb)
                    isAllCaps = false
                    minHeight = dpToPx(42)
                    minimumHeight = dpToPx(42)
                    background = GradientDrawable().apply {
                        setColor(emeraldArgb)
                        cornerRadius = dpToPx(12).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                rootCol.addView(headerRow)
                rootCol.addView(bodyTv)
                rootCol.addView(ctaBtn)
                addView(rootCol)

                this.iconView = iconView
                this.headlineView = headlineTv
                this.advertiserView = advertiserTv
                this.bodyView = bodyTv
                this.callToActionView = ctaBtn
            }
        },
        update = { adView ->
            (adView.headlineView as? TextView)?.text = nativeAd.headline.orEmpty()
            (adView.bodyView as? TextView)?.apply {
                text = nativeAd.body.orEmpty()
                visibility = if (nativeAd.body.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
            }
            (adView.advertiserView as? TextView)?.apply {
                text = nativeAd.advertiser ?: "Sponsored"
            }
            (adView.callToActionView as? Button)?.apply {
                text = nativeAd.callToAction ?: "Learn More"
                visibility = if (nativeAd.callToAction.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
            }
            (adView.iconView as? ImageView)?.apply {
                val drawable = nativeAd.icon?.drawable
                if (drawable != null) {
                    setImageDrawable(drawable)
                    visibility = android.view.View.VISIBLE
                } else {
                    visibility = android.view.View.GONE
                }
            }
            adView.setNativeAd(nativeAd)
        }
    )
}
