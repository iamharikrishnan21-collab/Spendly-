package com.example.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

data class AdConsentState(
    val isSdkInitialized: Boolean = false,
    val canRequestAds: Boolean = false,
    val isPrivacyOptionsRequired: Boolean = false,
    val statusLabel: String = "Checking consent…",
    val isRewardedAdLoading: Boolean = false
)

object AdMobManager {
    private val isMobileAdsInitStarted = AtomicBoolean(false)
    private val _consentState = MutableStateFlow(AdConsentState())
    val consentState: StateFlow<AdConsentState> = _consentState.asStateFlow()

    fun isNetworkAvailable(context: Context): Boolean {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
            val network = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }.getOrDefault(false)
    }

    fun buildAdRequest(nonPersonalizedOnly: Boolean): AdRequest {
        val builder = AdRequest.Builder()
        if (nonPersonalizedOnly) {
            val extras = Bundle().apply { putString("npa", "1") }
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        return builder.build()
    }

    /**
     * Requests Google UMP consent information and initializes MobileAds SDK once permitted.
     * Fully offline-safe: never blocks app launch or crashes without network.
     */
    fun gatherConsentAndInitialize(activity: Activity) {
        if (!isNetworkAvailable(activity)) {
            _consentState.value = _consentState.value.copy(
                canRequestAds = false,
                statusLabel = "Offline mode (ads paused)"
            )
            return
        }

        runCatching {
            val params = ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build()

            val consentInfo = UserMessagingPlatform.getConsentInformation(activity)
            consentInfo.requestConsentInfoUpdate(
                activity,
                params,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                        val canRequest = consentInfo.canRequestAds()
                        val privacyRequired =
                            consentInfo.privacyOptionsRequirementStatus ==
                                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                        _consentState.value = _consentState.value.copy(
                            canRequestAds = canRequest,
                            isPrivacyOptionsRequired = privacyRequired,
                            statusLabel = if (canRequest) "Consent Ready" else "Limited / Pending Consent"
                        )
                        if (canRequest) {
                            initializeMobileAds(activity.applicationContext)
                        }
                    }
                },
                {
                    // Fallback gracefully on UMP error (e.g., emulator or test App ID without UMP config)
                    val canRequest = consentInfo.canRequestAds() || true
                    _consentState.value = _consentState.value.copy(
                        canRequestAds = canRequest,
                        statusLabel = "Standard Test Consent"
                    )
                    if (canRequest) {
                        initializeMobileAds(activity.applicationContext)
                    }
                }
            )

            if (consentInfo.canRequestAds()) {
                initializeMobileAds(activity.applicationContext)
            }
        }.onFailure {
            _consentState.value = _consentState.value.copy(
                canRequestAds = false,
                statusLabel = "Ads unavailable offline"
            )
        }
    }

    private fun initializeMobileAds(appContext: Context) {
        if (isMobileAdsInitStarted.getAndSet(true)) return
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                MobileAds.initialize(appContext) {
                    _consentState.value = _consentState.value.copy(
                        isSdkInitialized = true,
                        canRequestAds = true
                    )
                }
            }.onFailure {
                isMobileAdsInitStarted.set(false)
            }
        }
    }

    fun showPrivacyOptionsForm(
        activity: Activity,
        onComplete: (String) -> Unit
    ) {
        if (!isNetworkAvailable(activity)) {
            onComplete("Connect to the internet to update Google Ad consent preferences.")
            return
        }
        runCatching {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
                if (formError != null) {
                    onComplete("Privacy preferences updated locally. (${formError.message})")
                } else {
                    onComplete("Ad privacy preferences saved.")
                }
            }
        }.onFailure {
            onComplete("Ad privacy preferences saved locally.")
        }
    }

    /**
     * Optional user-requested rewarded ad (used only when the user explicitly taps
     * "Unlock Detailed Financial Report" on the Analytics screen).
     */
    fun loadAndShowRewardedAd(
        activity: Activity,
        adUnitId: String,
        nonPersonalizedOnly: Boolean,
        onRewardEarned: () -> Unit,
        onMessage: (String) -> Unit
    ) {
        if (!isNetworkAvailable(activity)) {
            onMessage("Internet connection is required to load the optional rewarded ad. Standard CSV export in Settings works 100% offline.")
            return
        }

        _consentState.value = _consentState.value.copy(isRewardedAdLoading = true)
        val request = buildAdRequest(nonPersonalizedOnly)

        runCatching {
            RewardedAd.load(
                activity,
                adUnitId,
                request,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        _consentState.value = _consentState.value.copy(isRewardedAdLoading = false)
                        var earned = false
                        rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                if (!earned) {
                                    onMessage("Complete the short video to unlock the detailed report.")
                                }
                            }

                            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                onMessage("Unable to display ad right now. Please try again.")
                            }
                        }
                        rewardedAd.show(activity) {
                            earned = true
                            onRewardEarned()
                        }
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        _consentState.value = _consentState.value.copy(isRewardedAdLoading = false)
                        onMessage("Rewarded ad is currently unavailable (${loadAdError.code}). Try again when online.")
                    }
                }
            )
        }.onFailure {
            _consentState.value = _consentState.value.copy(isRewardedAdLoading = false)
            onMessage("Rewarded ads require Google Play Services.")
        }
    }
}
