package com.example.ads

/**
 * Centralized, configurable Google AdMob configuration.
 *
 * Uses Google's official test ad unit IDs by default. Real production ad unit IDs are
 * only used when [isProductionMode] is explicitly enabled AND valid production IDs are set.
 */
data class AdConfig(
    val isProductionMode: Boolean = false,
    val productionDashboardBannerUnitId: String = "",
    val productionHistoryBannerUnitId: String = "",
    val productionNativeUnitId: String = "",
    val productionRewardedUnitId: String = ""
) {
    val activeDashboardBannerId: String
        get() = if (isProductionMode && isValidAdUnitId(productionDashboardBannerUnitId)) {
            productionDashboardBannerUnitId
        } else {
            TEST_BANNER_UNIT_ID
        }

    val activeHistoryBannerId: String
        get() = if (isProductionMode && isValidAdUnitId(productionHistoryBannerUnitId)) {
            productionHistoryBannerUnitId
        } else {
            TEST_BANNER_UNIT_ID
        }

    val activeNativeId: String
        get() = if (isProductionMode && isValidAdUnitId(productionNativeUnitId)) {
            productionNativeUnitId
        } else {
            TEST_NATIVE_UNIT_ID
        }

    val activeRewardedId: String
        get() = if (isProductionMode && isValidAdUnitId(productionRewardedUnitId)) {
            productionRewardedUnitId
        } else {
            TEST_REWARDED_UNIT_ID
        }

    companion object {
        // Official Google AdMob Test Ad Unit IDs (Safe for development & emulator)
        const val TEST_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
        const val TEST_NATIVE_UNIT_ID = "ca-app-pub-3940256099942544/2247696110"
        const val TEST_REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

        // Native ad placement cadence in Transaction History (every 8-10 items)
        const val NATIVE_AD_INTERVAL = 9

        fun isValidAdUnitId(id: String): Boolean {
            val trimmed = id.trim()
            return trimmed.startsWith("ca-app-pub-") && trimmed.contains("/")
        }
    }
}
